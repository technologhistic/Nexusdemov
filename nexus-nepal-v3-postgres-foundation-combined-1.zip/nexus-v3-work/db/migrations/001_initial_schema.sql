-- Nexus Nepal initial PostgreSQL schema. Apply through `npm run db:migrate`.
-- User IDs accept UUID text, including the compact 32-hex representation used by the current app.
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY,
  name text NOT NULL CHECK (char_length(name) BETWEEN 2 AND 60),
  email text NOT NULL,
  password_hash text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz NULL,
  failed_count integer NOT NULL DEFAULT 0 CHECK (failed_count >= 0),
  locked_until timestamptz NULL,
  oauth_provider text NULL CHECK (oauth_provider IS NULL OR oauth_provider IN ('google', 'facebook')),
  oauth_subject text NULL,
  CONSTRAINT users_oauth_pair CHECK ((oauth_provider IS NULL) = (oauth_subject IS NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_normalized_uq ON users (lower(email));
CREATE UNIQUE INDEX IF NOT EXISTS users_oauth_identity_uq ON users (oauth_provider, oauth_subject) WHERE oauth_provider IS NOT NULL AND oauth_subject IS NOT NULL;

CREATE TABLE IF NOT EXISTS sessions (
  token_hash char(64) PRIMARY KEY CHECK (token_hash ~ '^[0-9a-f]{64}$'),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz NULL,
  CHECK (expires_at > created_at)
);
CREATE INDEX IF NOT EXISTS sessions_user_created_idx ON sessions (user_id, created_at);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions (expires_at) WHERE revoked_at IS NULL;

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  description text NULL,
  price_paisa bigint NOT NULL CHECK (price_paisa >= 0),
  currency char(3) NOT NULL DEFAULT 'NPR' CHECK (currency = 'NPR'),
  sku text UNIQUE,
  image_path text NULL,
  origin text NULL,
  warranty_text text NULL,
  return_policy_text text NULL,
  stock_on_hand integer NOT NULL DEFAULT 0 CHECK (stock_on_hand >= 0),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text NOT NULL UNIQUE,
  user_id uuid NULL REFERENCES users(id) ON DELETE SET NULL,
  customer_name text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  delivery_note text NULL,
  currency char(3) NOT NULL DEFAULT 'NPR' CHECK (currency = 'NPR'),
  subtotal_paisa bigint NOT NULL CHECK (subtotal_paisa >= 0),
  delivery_paisa bigint NOT NULL CHECK (delivery_paisa >= 0),
  total_paisa bigint NOT NULL CHECK (total_paisa >= 0 AND total_paisa = subtotal_paisa + delivery_paisa),
  status text NOT NULL DEFAULT 'pending_payment' CHECK (status IN ('pending_payment','confirmed','processing','shipped','delivered','cancelled')),
  payment_status text NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid','pending','paid','failed','refunded','partially_refunded')),
  payment_method text NULL CHECK (payment_method IS NULL OR payment_method IN ('esewa','khalti','cash_on_delivery')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS orders_user_created_idx ON orders (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS orders_payment_status_idx ON orders (payment_status, created_at);

CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NULL REFERENCES products(id) ON DELETE SET NULL,
  product_name_snapshot text NOT NULL,
  sku_snapshot text NULL,
  unit_price_paisa bigint NOT NULL CHECK (unit_price_paisa >= 0),
  quantity integer NOT NULL CHECK (quantity > 0),
  line_total_paisa bigint NOT NULL CHECK (line_total_paisa >= 0 AND line_total_paisa = unit_price_paisa * quantity),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS order_items_order_idx ON order_items (order_id);

-- Payment attempts are represented separately so retries and provider references
-- do not overwrite order history. No payment integration is enabled by this schema.
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  provider text NOT NULL CHECK (provider IN ('esewa','khalti')),
  provider_reference text NULL,
  provider_transaction_id text NULL,
  amount_paisa bigint NOT NULL CHECK (amount_paisa >= 0),
  currency char(3) NOT NULL DEFAULT 'NPR' CHECK (currency = 'NPR'),
  status text NOT NULL DEFAULT 'initiated' CHECK (status IN ('initiated','pending','completed','failed','cancelled','expired','refunded')),
  idempotency_key text NOT NULL UNIQUE,
  request_fingerprint text NULL,
  verified_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, provider_reference),
  UNIQUE (provider, provider_transaction_id)
);
CREATE INDEX IF NOT EXISTS payments_order_created_idx ON payments (order_id, created_at DESC);
