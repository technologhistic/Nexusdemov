# PostgreSQL implementation notes

## What changed in this pass
- Added a PostgreSQL-backed auth/session adapter behind the existing `src/lib/db.ts` interface.
- Production data access fails closed without `DATABASE_URL`; there is no production fallback to JSON. The check is deferred until data access so a build can run without production secrets.
- The local JSON adapter remains for development demos only. A corrupt or unreadable JSON file now fails closed instead of silently loading an empty database.
- Added the initial schema for users, sessions, products, orders, order items and payment attempts. User/session/order ownership keys use PostgreSQL UUID types; the current compact 32-hex user IDs are valid UUID input forms.
- Added a transaction-based migration runner (`npm run db:migrate`).
- Added a dry-run-first JSON auth importer (`npm run db:import-json`); use `-- --apply` only after reviewing its report and confirming the target auth tables are empty.
- Session insertion locks the user row while enforcing the five-session cap.

## Not completed / do not infer
- The JSON importer has not been run against a real `auth.json` or database.
- Product catalogue rows are not seeded into PostgreSQL; current catalogue rendering remains static.
- Order creation APIs, transactional stock management, payment callbacks, eSewa/Khalti integration, refunds and payment reconciliation are not implemented.
- The application has not been build-tested in this environment because package installation did not complete and dependencies were unavailable. `node --check` passed for both new JavaScript scripts; TypeScript/build validation still needs to run in a normal project environment.

## Safe first run
1. Provision an empty PostgreSQL database and a least-privilege application/migration role.
2. Configure `DATABASE_URL` as a secret and set `DATABASE_SSL=true` only if your provider requires verified TLS using the platform's trusted CA setup.
3. Run `npm install`, then `npm run typecheck` and `npm run build`.
4. Review `db/migrations/001_initial_schema.sql`, back up any existing data, then run `npm run db:migrate`.
5. Back up `.data/auth.json`; run `npm run db:import-json` (dry run), resolve every reported issue, then use `npm run db:import-json -- --apply` against the empty target only.
6. Test register, login, lockout, OAuth linking, session expiry/revocation and the five-session cap in staging.
7. Do not enable real payments until the release checklist's remaining gates pass.
