# Nexus Nepal V3 — Production Readiness Checklist
**Review date:** 10 Oct 2026 · **Method:** static inspection of the supplied ZIP/README/source. No build, penetration test, provider test, or legal review was run.

## Executive call
**NO-GO for real payments or real customer order fulfilment.** V3 is a useful demo with meaningful security and compliance foundations, but the checkout is deliberately simulated and persistence is file-backed. Enabling payment buttons or adding live keys would not make it production-ready.

## Solid foundations (retain, then test)
- [x] Password hashing uses Node `scrypt`, per-user salt, and server-side pepper; login has generic errors/dummy checks and lockout logic.
- [x] Session bearer token is generated server-side; only SHA-256 token hash is stored; cookie is HttpOnly, SameSite=Lax and uses `__Host-` in production; logout revokes the session.
- [x] Auth POST guard includes same-origin/challenge-style controls, JSON/body limits, and rate limiting (reviewed in `guard.ts`/auth routes).
- [x] OAuth implementation has PKCE/state-related code for Google/Facebook, disabled by default until configured.
- [x] Security headers are configured in `next.config.ts` (HSTS, nosniff, frame denial, referrer policy, COOP/CORP, etc.).
- [x] Privacy, terms, refund, cookies, grievance, business-information pages and consent UI exist.
- [x] Checkout visibly states that the payment flow is a demo and no real money is charged.

**Important qualification:** these are code-level observations, not proof of secure operation. Automated tests, deployment review, dependency audit and independent security testing remain outstanding.

## Demo-only / incomplete
- [ ] **JSON auth store:** `src/lib/db.ts` writes `.data/auth.json`, uses a process-local cache/queue, and catches any read/parse error as an empty database. Not safe across serverless instances or concurrent processes; can lose or appear to erase data.
- [ ] **Checkout is client-only:** `src/app/checkout/page.tsx` waits 900 ms, generates an ID from the current timestamp, clears the local cart, and displays success. There is no order-creation API, durable order record, payment request, callback, or provider verification.
- [ ] **Cart/catalog are not an authoritative inventory system:** cart state is client-side; catalogue appears bundled/static. Prices, stock, and order totals are not locked/revalidated in a server-side transaction.
- [ ] **Payment options are labels only:** eSewa and Khalti never get called. Bank details are explicitly demo values. No refunds, settlement/reconciliation, payment ledger, or payment event audit trail exists.
- [ ] **No order model / order-item snapshots / stock reservation** were found in the source tree reviewed.
- [ ] **Operational rate limiting:** auth rate-limit state is in memory; it will not coordinate across serverless instances and can reset on restarts. README already calls for Redis/Upstash or equivalent.
- [ ] **Legal/business details:** README says legal entity fields and DoCSCP listing number are placeholders. Policy pages need actual business details and qualified legal review; the UI’s “aligned” language is not a compliance certification.
- [ ] **OAuth production readiness:** provider apps, redirect URI allowlists, secrets, callback behavior, account-linking rules and recovery flows must be verified in each deployed environment.
- [ ] **Account lifecycle:** email verification, password reset, account recovery, session management UI and MFA are not implemented (README lists several as future work).

## What will break or become unsafe if real payments are enabled now
1. A customer can see “Order placed” without an order being persisted or a provider payment being made.
2. A forged/altered client amount or stale cart cannot be safely resolved because the server has no authoritative order calculation.
3. Duplicate clicks, retries, callback replays, timeouts and double submissions have no durable idempotency boundary.
4. No trusted payment-status verification exists; a redirect or browser result could be mistaken for payment confirmation if wired naively.
5. Stock oversell and price changes cannot be handled atomically.
6. User/session data can be lost or diverge between instances; a malformed/unreadable JSON file can be treated as an empty store.
7. Real bank instructions shown in demo checkout could misdirect funds if left unchanged.
8. Customer support cannot reliably trace an order, transaction reference, refund, delivery state or dispute from a durable audit trail.

## Release gates — all required before production payments
### Data & orders
- [ ] PostgreSQL schema/migrations approved; TLS, least privilege, backups/PITR and restore drill completed.
- [ ] Import reconciliation and rollback/recovery runbook approved; no silent data loss.
- [ ] Server-side order creation with immutable item/price snapshots, validated totals, shipping fee rules and currency.
- [ ] Transactional inventory reservation/decrement with concurrency controls and oversell tests.
- [ ] Unique order number, unique provider references, idempotent create/confirm/refund transitions.

### Payments (each provider separately)
- [ ] eSewa/Khalti merchant sandbox account and credentials acquired; happy, failed, canceled, pending, timeout, duplicate, mismatch and refund scenarios tested.
- [ ] Secret keys server-only and managed separately by environment; no secrets in repository/client bundles/logs.
- [ ] Callback/return input validated; provider status verified server-to-server; amount, currency, order ID and provider reference all match before fulfilment.
- [ ] Retry policy, reconciliation for ambiguous outcomes, refund process, settlement matching and alerting documented.
- [ ] Only one successful payment can fulfil an order; late/duplicate callbacks cannot double-ship or double-credit.

### Security, operations & legal
- [ ] Replace in-memory rate limits with shared infrastructure; configure production HTTPS, headers, secret management and deployment access controls.
- [ ] Automated tests for auth/session/checkout/payment state transitions; CI build/lint/typecheck; dependency and secret scans.
- [ ] Structured logs/metrics/alerts with sensitive fields redacted; incident response and backup restore exercised.
- [ ] Replace every legal/business placeholder; verify applicable business registration/PAN/VAT, DoCSCP listing and disclosures with counsel/authorities.
- [ ] Privacy/data-retention, support/grievance handling, refund and delivery operations staffed and tested.
- [ ] Final staging sign-off and explicit owner approval before switching any live credentials.

## Recommended immediate decision
Keep checkout in clearly labeled demo mode. Approve the Postgres schema and migration approach first; separately complete sandbox merchant onboarding and payment-flow design. Do not add live credentials or accept real payments in this release.
