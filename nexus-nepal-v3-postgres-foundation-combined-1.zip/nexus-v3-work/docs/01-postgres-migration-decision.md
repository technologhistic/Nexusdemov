# Decision Note: JSON Store → PostgreSQL
**Project:** Nexus Nepal V3 · **Status:** Decision for review, not implementation  
**Scope:** Users, sessions, products, orders · **Decision:** PostgreSQL is the production system of record; the JSON store remains local-demo-only.

## Decision and rationale
The current `src/lib/db.ts` stores users and sessions in `.data/auth.json`, with a process-local cache and mutation queue. That is convenient for a single-process demo, but it is not a safe production database: serverless filesystems can be ephemeral/read-only, multiple instances do not share the cache or queue, and read/parse failures currently fall back to an empty store. Concurrent writes across instances can lose updates. Do not enable real orders or payments on this store.

Use managed PostgreSQL with TLS, automated backups/PITR, least-privilege credentials, and a migration tool. Keep the application’s current repository-style boundary (`src/lib/db.ts`) as the seam, but replace file-backed persistence behind it only after the schema, migration, and rollback plan are approved. **No migration coding is part of this decision.**

## Proposed data model
Use UUID primary keys, UTC `timestamptz` timestamps, database constraints, and parameterized queries. Store money as integer minor units (NPR paisa) to avoid floating-point errors.

- **users**
  - `id uuid PK`
  - `name text NOT NULL`
  - `email text NOT NULL` with a unique index on normalized/lowercase email
  - `password_hash text NULL` (NULL for OAuth-only users; never store plaintext)
  - `oauth_provider text NULL`, `oauth_subject text NULL`; unique `(oauth_provider, oauth_subject)` when present
  - `created_at timestamptz NOT NULL`, `last_login_at timestamptz NULL`
  - `failed_count integer NOT NULL DEFAULT 0`, `locked_until timestamptz NULL`
  - Do not persist the current empty-string password sentinel; normalize it to NULL.

- **sessions**
  - `token_hash char(64) PK` (SHA-256 hex digest only; never store the bearer token)
  - `user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE`
  - `created_at timestamptz NOT NULL`, `expires_at timestamptz NOT NULL`, `revoked_at timestamptz NULL`
  - Index `(user_id, created_at)` and `(expires_at)`; enforce the five-active-session policy transactionally, not in application memory alone.

- **products**
  - `id uuid PK`; `slug text NOT NULL UNIQUE`; `name text NOT NULL`; `description text`
  - `price_paisa bigint NOT NULL CHECK (price_paisa >= 0)`
  - `currency char(3) NOT NULL DEFAULT 'NPR'`
  - `sku text UNIQUE`, `image_path text`, `origin text`, `warranty_text text`, `return_policy_text text`
  - `stock_on_hand integer NOT NULL DEFAULT 0 CHECK (stock_on_hand >= 0)`
  - `is_active boolean NOT NULL DEFAULT true`, `created_at`, `updated_at`
  - Product catalogue currently appears code/static-file driven; import it as an explicit, reviewed seed, not by scraping rendered UI.

- **orders**
  - `id uuid PK`; `order_number text NOT NULL UNIQUE`
  - `user_id uuid NULL REFERENCES users(id)` (allow guest checkout only if intentionally supported)
  - Snapshot shipping fields: `customer_name`, `phone`, `address`, `city`, `delivery_note`
  - `currency char(3) NOT NULL DEFAULT 'NPR'`
  - `subtotal_paisa bigint NOT NULL`, `delivery_paisa bigint NOT NULL`, `total_paisa bigint NOT NULL`, all non-negative with `total = subtotal + delivery`
  - `status text NOT NULL` constrained to reviewed states such as `pending_payment`, `confirmed`, `processing`, `shipped`, `delivered`, `cancelled`
  - `payment_status text NOT NULL` constrained to `unpaid`, `pending`, `paid`, `failed`, `refunded`, `partially_refunded`
  - `payment_method text`, `created_at`, `updated_at`
  - **`order_items` is required** to preserve purchase snapshots: `id uuid PK`, `order_id FK`, `product_id FK NULL` (retain history if product is removed), `product_name_snapshot`, `sku_snapshot`, `unit_price_paisa`, `quantity`, `line_total_paisa`; constrain quantity > 0 and line totals.
  - Payment gateway references should live in a separate `payments` table in the payment-integration phase, unique by provider transaction reference / `pidx` and linked to the order. Do not overload the order row with retry history.

## Migration path (paper plan)
1. **Inventory & freeze:** capture a versioned backup of `auth.json`; record counts and hashes; identify any other `.data` files. Stop writes during the one-time cutover.
2. **Schema first:** create reviewed migrations for `users`, `sessions`, `products`, `orders`, `order_items`; add constraints/indexes. No production payments yet.
3. **Transform:** normalize emails; convert millisecond epoch timestamps to UTC timestamps; convert empty OAuth password hashes to NULL; retain only hashed session tokens; reject/resolve duplicate emails and invalid records explicitly.
4. **Load & reconcile:** import users/sessions and reviewed product seed; compare source/destination counts, unique keys, expiry/lockout behavior, and sampled records. Do not silently discard bad rows.
5. **Switch:** deploy the PostgreSQL adapter behind the existing repository interface; use one authoritative writer. Do not run dual writes without a designed reconciliation mechanism.
6. **Verify & rollback:** smoke-test register/login/logout/session expiry/lockout and product/order transactions; monitor DB errors. Rollback by redeploying the previous demo build only before production writes; after writes begin, restore/replay must be a documented database recovery procedure, not a file-store switchback.

## Acceptance gates
- Unique normalized email and OAuth-subject constraints; foreign keys; order totals checked server-side.
- TLS, secret manager, least-privilege app role, backups/PITR and tested restore.
- Migration report reconciles counts and exceptions; rollback/recovery rehearsal passes.
- Checkout/order creation is server-side and transactional; stock cannot go negative.
- No real payments until separate payment state machine, provider verification, and idempotent fulfilment are reviewed.
