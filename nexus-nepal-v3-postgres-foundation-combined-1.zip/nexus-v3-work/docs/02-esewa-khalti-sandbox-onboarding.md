# eSewa + Khalti: Sandbox Onboarding Notes
**Checked against official provider docs on 10 Oct 2026.** This is an onboarding checklist, not a claim that merchant accounts have been created or tests run.

## eSewa ePay (web checkout)
**Official docs**
- ePay V2: https://developer.esewa.com.np/pages/Epay-V2
- Test credentials: https://developer.esewa.com.np/pages/Test-credentials
- General introduction: https://developer.esewa.com.np/pages/Introduction

### Accounts and setup
1. A merchant/business integration is required. The official docs say eSewa provides partner merchants with technical documentation and a test merchant service code; contact eSewa/complete its merchant onboarding to obtain production merchant credentials and settlement details.
2. For sandbox checkout, use the documented test service code `EPAYTEST` and UAT endpoint `https://rc-epay.esewa.com.np/api/epay/main/v2/form`.
3. The docs publish UAT test-user credentials for logging in to the eSewa test payment flow. Use only the current credentials shown on the official test-credentials page; do not use a personal wallet.
4. Implement the server-side request signature using HMAC-SHA256 and Base64. For ePay V2, the signed fields include `total_amount`, `transaction_uuid`, and `product_code` in the documented order. Keep the UAT secret out of browser code and source control.
5. Configure success/failure URLs and a unique merchant `transaction_uuid` per payment attempt. On return, verify the transaction with eSewa’s status/verification endpoint before marking an order paid or fulfilling it.
6. Test success, failure/cancel, timeout, duplicate callback/return, amount mismatch, and status-query recovery. The docs specifically advise status checks if no response arrives and verification to filter fraudulent/mismatched payments.
7. After successful sandbox testing, request/complete production merchant onboarding and use the production endpoint and credentials supplied for the merchant account. Keep sandbox and production credentials/environment variables separate.

### Idempotency: what the docs do and do not promise
- **ePay V2:** the documented unique `transaction_uuid` is a merchant transaction identifier and the status API supports recovery/reconciliation. The ePay V2 page does **not** document a generic `Idempotency-Key` header or an explicit duplicate-request guarantee. Treat provider-side idempotency as **not confirmed**; enforce a unique internal payment-attempt key and reconcile status before retrying an uncertain request.
- **eSewa Intent is a different API:** its official page explicitly describes idempotent processing and a booking flow (`booking_id`, `correlation_id`) with a status endpoint. That statement should not be assumed to apply to standard ePay V2. If choosing Intent, confirm exact duplicate-booking semantics with eSewa before relying on them.

## Khalti KPG-2 Web Checkout
**Official docs**
- Web Checkout: https://docs.khalti.com/khalti-epayment/
- Getting Started / Test Environment / Going Live: https://docs.khalti.com/getting-started/

### Accounts and setup
1. Create a **sandbox merchant account** at https://test-admin.khalti.com/ (linked by Khalti’s docs). The docs specify `987654` as the sandbox login OTP.
2. Retrieve the sandbox **server-side secret key** from the sandbox merchant dashboard. Use the `live_secret_key` from `test-admin.khalti.com` only with sandbox. Never expose it in client-side code.
3. Use the sandbox API base `https://dev.khalti.com/api/v2/`. Initiate payment server-side with `POST /epayment/initiate/`, Authorization header `Key <sandbox-secret>`, and required `return_url`, `website_url`, `amount` (integer paisa), unique `purchase_order_id`, and `purchase_order_name`.
4. Store returned `pidx` and `purchase_order_id` against the pending order, then redirect the customer to the returned `payment_url`.
5. Treat the browser return as a signal, not proof. Call `POST /epayment/lookup/` with `pidx` and server-side authorization; only `Completed` is success. Hold `Pending`/`Initiated`; do not fulfil canceled, expired, refunded, or other non-completed transactions.
6. Sandbox customer credentials documented by Khalti: test Khalti IDs `9800000000`–`9800000005`, MPIN `1111`, OTP `987654`. Docs say e-banking and debit/credit card payments are not supported in the test environment.
7. After integration tests, create/complete a live merchant account at https://admin.khalti.com/, replace sandbox base URL and keys with production values from the live dashboard, and complete the KYC process. Khalti docs warn that transactions may be limited to NPR 200 until KYC is completed and Khalti is contacted to remove the limit.

### Idempotency: what the docs and local design must handle
- Khalti Web Checkout documents unique `purchase_order_id`, returned `pidx`, and a payment lookup API. The current public Web Checkout docs do **not** document a general `Idempotency-Key` header or guarantee that repeating an initiate request cannot create another payment attempt. Provider-side idempotency is therefore **not confirmed**.
- Make the merchant `purchase_order_id` unique in the database; persist the `pidx`; make callback/lookup processing idempotent locally with a unique provider reference and a guarded order-state transition. On network timeout, lookup/reconcile before initiating a new attempt.

## Shared security rules
- Server-side secrets only; separate sandbox/live credentials; rotate exposed keys.
- Derive amounts from the server’s order + item snapshots, never from browser-submitted totals.
- Validate provider status **and amount/currency/order reference** before changing state.
- Use HTTPS return/callback URLs, structured redacted logs, timeouts, bounded retries, and an operational reconciliation queue.
- Do not enable real payments from the current V3 checkout: it currently simulates the flow and does not call either provider.
