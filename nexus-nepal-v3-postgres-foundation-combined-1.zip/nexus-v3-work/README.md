# Nexus Nepal — E-commerce

Authentic Nepali products store built with **Next.js 15 + React 19**.

## Design System
Exact color palette from the original login form:
- Olive `#3B4A1F`
- Olive Deep `#232D0F`
- Lime `#B8F235`
- Crème `#F5EEDC`
- Black `#14161A`
- Slate `#5C6678`

## Features (v0.2)
- Homepage with hero + featured products
- Product listing + detail pages
- **Secure accounts**: register, sign in, sign out, protected /account page
- Login/Register with pure-CSS animated social tabs (Facebook / Instagram / Twitter / Google / Email)
- **Real OAuth 2.0 + PKCE** for Google & Facebook (enable via env vars)
- 8 local product illustrations in `public/products/`
- Cart placeholder
- Sticky header with animated logo
- Fully responsive
- Ready for Vercel deployment

## Run locally
```bash
cd nexus-nepal-shop
npm install
cp .env.example .env.local   # fill AUTH_SECRET at minimum
npm run dev
```

Open http://localhost:3000

## Enable Social Login
1. Create OAuth apps:
   - Google → https://console.cloud.google.com/apis/credentials
   - Facebook → https://developers.facebook.com/apps/
2. Set authorized redirect URIs to:
   - `http://localhost:3000/api/auth/callback/google`
   - `http://localhost:3000/api/auth/callback/facebook`
   - (and the production equivalents)
3. Put the Client ID / Secret in `.env.local` and set:
   ```
   NEXT_PUBLIC_GOOGLE_ENABLED=1
   NEXT_PUBLIC_FACEBOOK_ENABLED=1
   ```

## Security (accounts)
No new dependencies — built on Node's `crypto` and Next.js.

| Threat | Defence |
|---|---|
| Stolen database | Passwords hashed with **scrypt** (N=32768) + per-user salt + server-side pepper; session tokens stored only as SHA-256 hashes |
| Password guessing | 12+ char policy, common-password checks; **5 failed logins → 15 min lock** (doubles, max 6 h); per-account + per-IP rate limits |
| Account enumeration / timing | Identical error + dummy hash check + random delay |
| Bots & scripts | Hidden **honeypot**; signed single-use time-gated form token; bot UA blocked; JSON-only 4 KB limit; optional **Cloudflare Turnstile** |
| CSRF | Same-origin check + `SameSite=Lax` + single-use challenge |
| Session theft | `HttpOnly`, `Secure`, `__Host-` cookie (prod); 256-bit token; revoke on logout; max 5 sessions/user |
| XSS / clickjacking | Per-request **CSP nonce** (`strict-dynamic`), `frame-ancestors 'none'`, HSTS, nosniff, Referrer/Permissions, COOP/CORP |
| OAuth attacks | **PKCE (S256)** + signed state + short-lived verifier cookie + rate limits |

### Before going live
1. Set `AUTH_SECRET` (`openssl rand -base64 48`) — production fails closed if missing.
2. PostgreSQL persistence is now available through `DATABASE_URL`. Production startup fails closed if it is missing; JSON storage is local-demo-only.
3. Apply schema migrations to an empty/approved PostgreSQL database with `npm run db:migrate` after setting `DATABASE_URL`. Review the SQL before applying it. The migration creates users, sessions, products, orders, order items and payment-attempt tables; it does not seed products. To migrate existing auth data, first back up `.data/auth.json`, run `npm run db:import-json` for a dry run, inspect the report, then run `npm run db:import-json -- --apply` only against an empty, approved target database.
4. Rate limits and single-use form challenge state are still in-memory → use shared infrastructure such as Redis/Upstash and review distributed request protections before a multi-instance deployment.
5. Turn on Turnstile (free) if you want extra bot protection.
6. Always serve over HTTPS.

## Next steps
- Email verification + forgot password
- 2FA (TOTP)
- Instagram / Twitter OAuth (same pattern as Google/Facebook)
- Cart + payments (eSewa / Khalti)
- Admin dashboard

---

## Executive / Investor Demo (v0.3 Compliance Layer)

This build is intentionally positioned as a **lawsuit-resistant, Nepal-law-aware demo** for CEO, CSO, CMO, CFO, MD and investors.

### What is live and visible right now
| Page / Feature | Path | Purpose |
|---|---|---|
| Privacy Policy | `/privacy` | Individual Privacy Act 2075 + E-Commerce Act §12 |
| Terms & Conditions | `/terms` | Contract formation, liability, governing law (Nepal) |
| Refund / Return / Cancellation | `/refund` | Strong buyer rights when goods don’t match description (Act §10) |
| Cookie Policy | `/cookies` | Consent-based cookie use |
| Online Grievance | `/grievance` | 15-day target response channel + consent |
| Business Information | `/business` | Mandatory public disclosures (name, PAN, listing no., contacts) |
| Cookie consent banner | Site-wide | Essential vs optional |
| Registration consent checkbox | `/register` | Explicit privacy + terms consent |
| Checkout consent checkbox | `/checkout` | Terms + privacy + refund acknowledgement |
| Product disclosures | Product detail | Price incl. tax note, warranty, delivery, origin, return rights |
| Footer legal block | All pages | Links + placeholder legal entity fields |
| Homepage compliance strip | `/` | Visible “Nepal E-Commerce Act aligned” bar |

### Security foundations already in place
- scrypt password hashing + lockout + rate limits + honeypot
- Security headers (HSTS, nosniff, DENY frame, COOP/CORP, etc.)
- OAuth 2.0 + PKCE skeleton
- No real payments charged in demo mode

### What leadership must still complete before real go-live (Phase 0)
1. Register business entity + obtain PAN (VAT if required).
2. **Mandatory**: Apply for DoCSCP e-commerce portal listing and display the Platform Listing Number.
3. Replace all `[bracketed]` placeholders with real legal name, address, PAN, listing number, contacts.
4. Lawyer review of the four policy pages.
5. Switch JSON file store → Postgres; integrate eSewa/Khalti with idempotency; real inventory consistency.
6. Do **not** accept real customer payments until the above is done.

### How to run the demo for stakeholders
```bash
cd nexus-nepal-shop
npm install
cp .env.example .env.local   # set AUTH_SECRET at minimum
npm run dev
```
Walk through: Home → Compliance strip → Business Info → Privacy / Refund / Grievance → Register (consent) → Product page (tax + return note) → Checkout (consent).

This demonstrates seriousness about legal risk, consumer rights, and operational discipline — the language investors and regulators expect to see.


## PostgreSQL persistence (migration foundation)

- Local demo: if `DATABASE_URL` is blank outside production, the app uses `.data/auth.json`. Corrupt/unreadable JSON now fails closed instead of silently appearing empty.
- Staging/production: configure `DATABASE_URL` as a secret. The app refuses to start in production without it; it does not silently fall back to JSON.
- Schema: `db/migrations/001_initial_schema.sql`. Migration runner: `scripts/migrate.mjs`; run `npm run db:migrate` from the project root.
- The migration runner applies each SQL migration in a transaction and records it in `schema_migrations`. Take a database backup and review the target environment before applying migrations.
- The auth JSON import is an explicit dry-run-first script and refuses to merge into non-empty auth tables. It does **not** seed the product catalogue, implement order APIs, or integrate eSewa/Khalti. Do not enable real payments.
- The `payments` table is only a schema foundation; it does not mean provider payment processing is implemented.
