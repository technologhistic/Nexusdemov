import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Privacy Policy — Nexus Nepal",
  description:
    "How Nexus Nepal collects, uses and protects your personal data under Nepal’s Individual Privacy Act 2075 and Electronic Commerce Act 2081.",
};

export default function PrivacyPage() {
  return (
    <div className="container" style={{ maxWidth: 800, padding: "48px 20px 80px" }}>
      <p style={{ fontSize: 13, color: "var(--slate)", marginBottom: 8 }}>
        <Link href="/" style={{ color: "var(--olive)" }}>
          Home
        </Link>{" "}
        / Privacy Policy
      </p>
      <h1 style={{ fontSize: 32, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 8 }}>
        Privacy Policy
      </h1>
      <p style={{ color: "var(--slate)", marginBottom: 32, fontSize: 14 }}>
        Last updated: 8 October 2026 · Compliant with Individual Privacy Act 2075 &amp; Electronic
        Commerce Act 2081 (Section 12)
      </p>

      <div className="legal-prose" style={{ lineHeight: 1.7, color: "var(--olive-deep)", fontSize: 15 }}>
        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>1. Who we are</h2>
          <p>
            This Privacy Policy applies to the e-commerce platform operated by{" "}
            <strong>[Legal Business Name]</strong> (“Nexus Nepal”, “we”, “us”), registered at{" "}
            <strong>[Full Registered Address, Ward, Municipality, District, Nepal]</strong>.
          </p>
          <ul>
            <li>Business Registration / Company Registration No.: [Number]</li>
            <li>PAN: [Number] · VAT (if applicable): [Number]</li>
            <li>DoCSCP E-Commerce Platform Listing Number: [To be obtained &amp; displayed]</li>
            <li>
              Contact for privacy &amp; data requests:{" "}
              <a href="mailto:privacy@nexusnepal.example">privacy@nexusnepal.example</a> · Phone: [Number]
            </li>
            <li>
              Grievance Officer: [Name / Role] —{" "}
              <a href="mailto:grievance@nexusnepal.example">grievance@nexusnepal.example</a>
            </li>
          </ul>
          <p style={{ fontSize: 13, color: "var(--slate)" }}>
            Replace the bracketed placeholders with your actual legal details before go-live. These
            details must also appear publicly on the platform as required by the E-Commerce Act.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>2. What personal data we collect and why (purpose limitation)</h2>
          <p>We collect only the data necessary to provide our services:</p>
          <ul>
            <li>
              <strong>Account &amp; identity:</strong> name, email address, phone number — to create
              and secure your account and communicate about orders.
            </li>
            <li>
              <strong>Order &amp; delivery:</strong> delivery address, contact phone — to fulfil and
              deliver orders.
            </li>
            <li>
              <strong>Payment metadata:</strong> transaction reference, payment method, status
              (full card or wallet credentials are handled by licensed payment gateways; we do not
              store full payment instrument details).
            </li>
            <li>
              <strong>Technical &amp; security:</strong> IP address, browser/device type, session
              identifiers, basic logs — for security, fraud prevention, rate limiting and
              troubleshooting.
            </li>
            <li>
              <strong>Cookies:</strong> essential cookies for login, cart and security; optional
              analytics only with consent (see Cookie Policy).
            </li>
          </ul>
          <p>
            We do <strong>not</strong> sell your personal data. We do not use it for unrelated
            marketing without separate, clear consent.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>3. Consent</h2>
          <p>
            Under the Individual Privacy Act 2075, we obtain informed consent before collecting
            personal information. By creating an account, placing an order, or submitting a form that
            includes a consent checkbox, you consent to the processing described in this policy for
            the stated purposes. You may withdraw consent or request deletion (subject to legal
            retention obligations) by contacting us.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>4. Sharing and disclosure</h2>
          <p>
            We share personal data only as needed to fulfil the transaction (e.g. delivery partners,
            NRB-approved payment gateways) or as required by Nepali law. The E-Commerce Act expressly
            permits sharing of transaction-relevant information among buyer, business and delivery
            provider for fulfilment. We do not share data with third parties for their independent
            marketing.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>5. Your rights</h2>
          <p>
            Consistent with the Individual Privacy Act 2075 and E-Commerce Act Section 12, you may:
          </p>
          <ul>
            <li>Access the personal information we hold about you</li>
            <li>Request correction or amendment of inaccurate data</li>
            <li>Request deactivation or deletion of your identity-related information (subject to
              legal retention for tax, accounting and dispute resolution)</li>
            <li>Withdraw consent where processing is based on consent</li>
          </ul>
          <p>
            To exercise these rights, email{" "}
            <a href="mailto:privacy@nexusnepal.example">privacy@nexusnepal.example</a> or use the{" "}
            <Link href="/grievance">Grievance form</Link>. We aim to respond within a reasonable
            time and in any event within the timelines expected under applicable law.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>6. Security and retention</h2>
          <p>
            Passwords are hashed using strong, memory-hard algorithms (scrypt) with per-user salt
            and server-side pepper. Session tokens are stored only as cryptographic hashes.
            Transmission is protected by HTTPS. Access to customer data is limited to personnel who
            need it for fulfilment or support. We retain order and transaction records as required
            for tax, accounting and consumer dispute purposes, then delete or anonymise.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>7. Children</h2>
          <p>
            Our services are not directed at children under 16. We do not knowingly collect personal
            data from children. If you believe we have, contact us immediately.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>8. Changes</h2>
          <p>
            We may update this policy to reflect legal or operational changes. The “Last updated”
            date will change. Material changes will be highlighted on the platform where
            appropriate.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>9. Contact &amp; grievance</h2>
          <p>
            Privacy requests:{" "}
            <a href="mailto:privacy@nexusnepal.example">privacy@nexusnepal.example</a>
            <br />
            Grievance / complaint:{" "}
            <Link href="/grievance">Online Grievance Form</Link> or{" "}
            <a href="mailto:grievance@nexusnepal.example">grievance@nexusnepal.example</a>
            <br />
            We aim to acknowledge and resolve grievances within 15 days where practicable.
          </p>
        </section>
      </div>

      <div style={{ marginTop: 40, padding: 16, background: "rgba(184,242,53,0.12)", borderRadius: 12, fontSize: 13 }}>
        <strong>Demo note for leadership:</strong> This page demonstrates Nepal-compliant privacy
        disclosures. Replace all [bracketed] placeholders with real legal entity data and obtain
        DoCSCP listing before accepting real customer data or payments.
      </div>
    </div>
  );
}

const h2: React.CSSProperties = {
  fontSize: 18,
  fontWeight: 700,
  color: "var(--olive-deep)",
  marginBottom: 10,
  marginTop: 4,
};
