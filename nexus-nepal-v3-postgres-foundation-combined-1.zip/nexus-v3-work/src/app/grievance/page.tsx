"use client";

import { useState } from "react";
import Link from "next/link";

export default function GrievancePage() {
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    // Demo: no backend yet — simulate success for investor demo
    await new Promise((r) => setTimeout(r, 800));
    setSent(true);
    setBusy(false);
  }

  return (
    <div className="container" style={{ maxWidth: 640, padding: "48px 20px 80px" }}>
      <p style={{ fontSize: 13, color: "var(--slate)", marginBottom: 8 }}>
        <Link href="/" style={{ color: "var(--olive)" }}>
          Home
        </Link>{" "}
        / Grievance Redressal
      </p>
      <h1 style={{ fontSize: 32, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 8 }}>
        Online Grievance Redressal
      </h1>
      <p style={{ color: "var(--slate)", marginBottom: 28, fontSize: 15, lineHeight: 1.6 }}>
        We take every complaint seriously. Under Nepal’s e-commerce framework we aim to acknowledge
        and resolve grievances within <strong>15 days</strong> where practicable. Please provide as
        much detail as possible so we can investigate quickly.
      </p>

      {sent ? (
        <div
          style={{
            padding: 24,
            background: "rgba(184,242,53,0.15)",
            borderRadius: 16,
            border: "1px solid rgba(59,74,31,0.15)",
          }}
        >
          <h2 style={{ fontSize: 20, fontWeight: 700, color: "var(--olive-deep)", marginBottom: 8 }}>
            Grievance submitted
          </h2>
          <p style={{ color: "var(--olive-deep)", lineHeight: 1.6 }}>
            Thank you. In a production environment this would create a tracked ticket with a
            reference number and email confirmation. Our team aims to respond within 15 days.
            Reference for this demo: <strong>GRV-DEMO-{Date.now().toString(36).toUpperCase()}</strong>
          </p>
          <Link href="/" className="btn-lime" style={{ display: "inline-block", marginTop: 16, padding: "10px 20px" }}>
            Return home
          </Link>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="card" style={{ padding: 28, display: "grid", gap: 16 }}>
          <div>
            <label htmlFor="name" style={labelStyle}>
              Full name *
            </label>
            <input id="name" name="name" required className="nx-input-plain" autoComplete="name" />
          </div>
          <div>
            <label htmlFor="email" style={labelStyle}>
              Email *
            </label>
            <input id="email" name="email" type="email" required className="nx-input-plain" autoComplete="email" />
          </div>
          <div>
            <label htmlFor="phone" style={labelStyle}>
              Phone
            </label>
            <input id="phone" name="phone" type="tel" className="nx-input-plain" autoComplete="tel" />
          </div>
          <div>
            <label htmlFor="order" style={labelStyle}>
              Order number (if applicable)
            </label>
            <input id="order" name="order" className="nx-input-plain" placeholder="e.g. NX-2026-00XXX" />
          </div>
          <div>
            <label htmlFor="category" style={labelStyle}>
              Category *
            </label>
            <select id="category" name="category" required className="nx-input-plain" defaultValue="">
              <option value="" disabled>
                Select…
              </option>
              <option value="product-mismatch">Product does not match description</option>
              <option value="refund">Refund / return issue</option>
              <option value="delivery">Delivery delay or damage</option>
              <option value="payment">Payment problem</option>
              <option value="privacy">Privacy / data request</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label htmlFor="message" style={labelStyle}>
              Description of the issue *
            </label>
            <textarea
              id="message"
              name="message"
              required
              rows={5}
              className="nx-input-plain"
              placeholder="What happened, when, and what resolution you seek…"
            />
          </div>
          <label style={{ display: "flex", gap: 10, alignItems: "flex-start", fontSize: 13, color: "var(--olive-deep)" }}>
            <input type="checkbox" required style={{ marginTop: 3 }} />
            <span>
              I consent to the processing of the personal data submitted in this form for the purpose
              of investigating and resolving my grievance, in accordance with the{" "}
              <Link href="/privacy" style={{ color: "var(--olive)" }}>
                Privacy Policy
              </Link>
              .
            </span>
          </label>
          <button
            type="submit"
            className="btn-primary"
            disabled={busy}
            style={{ height: 48, borderRadius: 24, opacity: busy ? 0.7 : 1 }}
          >
            {busy ? "Submitting…" : "Submit grievance"}
          </button>
          <p style={{ fontSize: 12, color: "var(--slate)", textAlign: "center" }}>
            Demo form — submissions are not stored yet. Production will log every ticket for audit
            and DoCSCP readiness.
          </p>
        </form>
      )}

      <style jsx global>{`
        .nx-input-plain {
          width: 100%;
          height: 48px;
          padding: 0 14px;
          border: 1px solid rgba(59, 74, 31, 0.18);
          border-radius: 12px;
          background: rgba(245, 238, 220, 0.45);
          font: inherit;
          font-size: 15px;
        }
        textarea.nx-input-plain {
          height: auto;
          padding: 12px 14px;
          resize: vertical;
        }
        select.nx-input-plain {
          appearance: auto;
        }
        .nx-input-plain:focus {
          outline: none;
          border-color: var(--olive);
          box-shadow: 0 0 0 3px rgba(184, 242, 39, 0.4);
        }
      `}</style>
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: "block",
  fontWeight: 600,
  fontSize: 13,
  marginBottom: 6,
  color: "var(--olive-deep)",
};
