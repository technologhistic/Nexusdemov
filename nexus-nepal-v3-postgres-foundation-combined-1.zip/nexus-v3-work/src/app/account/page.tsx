import Link from "next/link";
import { redirect } from "next/navigation";
import LogoutButton from "@/components/LogoutButton";
import { getCurrentUser } from "@/lib/session";

export const metadata = { title: "Your account — Nexus Nepal", robots: { index: false } };

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  return (
    <div className="container" style={{ padding: "48px 20px 64px", maxWidth: 560 }}>
      <div className="card" style={{ padding: 28, display: "grid", gap: 20 }}>
        <div>
          <div style={{ fontSize: 13, color: "var(--slate)" }}>Signed in</div>
          <h1 style={{ fontSize: 28, fontWeight: 800, color: "var(--olive-deep)" }}>Namaste, {user.name.split(" ")[0]} 🙏</h1>
        </div>
        <div style={{ display: "grid", gap: 4, fontSize: 15 }}>
          <div><span style={{ color: "var(--slate)" }}>Name: </span>{user.name}</div>
          <div><span style={{ color: "var(--slate)" }}>Email: </span>{user.email}</div>
        </div>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <Link href="/products" className="btn-lime">Continue shopping</Link>
          <LogoutButton />
        </div>
      </div>
    </div>
  );
}
