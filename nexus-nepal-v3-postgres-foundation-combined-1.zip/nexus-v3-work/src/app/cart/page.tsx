"use client";

import Link from "next/link";
import { useCart } from "@/lib/cart";
import ProductImage from "@/components/ProductImage";

function formatPrice(n: number) {
  return `NPR ${n.toLocaleString("en-NP")}`;
}

export default function CartPage() {
  const { lines, subtotal, setQty, remove, count } = useCart();

  if (count === 0) {
    return (
      <div className="container" style={{ padding: "48px 20px 64px", textAlign: "center" }}>
        <h1 style={{ fontSize: 32, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 12 }}>Your Cart</h1>
        <p style={{ color: "var(--slate)", marginBottom: 32 }}>Cart is empty. Start shopping!</p>
        <Link href="/products" className="btn-primary">
          Browse Products →
        </Link>
      </div>
    );
  }

  return (
    <div className="container" style={{ padding: "32px 20px 64px" }}>
      <h1 style={{ fontSize: 28, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 24 }}>
        Your Cart ({count} item{count === 1 ? "" : "s"})
      </h1>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 32, alignItems: "start" }} className="cart-grid">
        <div style={{ display: "grid", gap: 16 }}>
          {lines.map(({ product, qty, lineTotal }) => (
            <div
              key={product.id}
              className="card"
              style={{
                display: "grid",
                gridTemplateColumns: "100px 1fr auto",
                gap: 16,
                padding: 16,
                alignItems: "center",
              }}
            >
              <div style={{ width: 100, height: 100, borderRadius: 12, overflow: "hidden", background: "#e8e0c8" }}>
                <ProductImage src={product.image} alt={product.name} />
              </div>
              <div>
                <Link href={`/products/${product.slug}`} style={{ fontWeight: 700, color: "var(--olive-deep)" }}>
                  {product.name}
                </Link>
                <div style={{ fontSize: 13, color: "var(--slate)", marginTop: 4 }}>{product.brand}</div>
                <div style={{ fontWeight: 700, color: "var(--olive)", marginTop: 8 }}>{formatPrice(product.price)}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 10 }}>
                  <button
                    type="button"
                    onClick={() => setQty(product.id, qty - 1)}
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 8,
                      border: "1px solid rgba(59,74,31,0.2)",
                      background: "#fff",
                    }}
                  >
                    −
                  </button>
                  <span style={{ minWidth: 28, textAlign: "center", fontWeight: 600 }}>{qty}</span>
                  <button
                    type="button"
                    onClick={() => setQty(product.id, qty + 1)}
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 8,
                      border: "1px solid rgba(59,74,31,0.2)",
                      background: "#fff",
                    }}
                  >
                    +
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(product.id)}
                    style={{ marginLeft: 12, color: "#8A1C12", fontSize: 13, background: "none", border: 0 }}
                  >
                    Remove
                  </button>
                </div>
              </div>
              <div style={{ fontWeight: 800, fontSize: 18, color: "var(--olive-deep)" }}>{formatPrice(lineTotal)}</div>
            </div>
          ))}
        </div>

        <div className="card" style={{ padding: 24, position: "sticky", top: 96 }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Order Summary</h2>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ color: "var(--slate)" }}>Subtotal</span>
            <span style={{ fontWeight: 700 }}>{formatPrice(subtotal)}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16, fontSize: 14 }}>
            <span style={{ color: "var(--slate)" }}>Delivery</span>
            <span>Calculated at checkout</span>
          </div>
          <div
            style={{
              borderTop: "1px solid rgba(59,74,31,0.12)",
              paddingTop: 16,
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 20,
            }}
          >
            <span style={{ fontWeight: 700 }}>Total</span>
            <span style={{ fontWeight: 800, fontSize: 20, color: "var(--olive)" }}>{formatPrice(subtotal)}</span>
          </div>
          <Link
            href="/checkout"
            className="btn-primary"
            style={{ display: "flex", justifyContent: "center", alignItems: "center", height: 48, borderRadius: 24, width: "100%" }}
          >
            Proceed to Checkout →
          </Link>
          <p style={{ fontSize: 12, color: "var(--slate)", marginTop: 12, textAlign: "center" }}>
            eSewa · Khalti · Bank · Cash on Delivery
          </p>
        </div>
      </div>

      <style jsx>{`
        @media (max-width: 800px) {
          .cart-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
