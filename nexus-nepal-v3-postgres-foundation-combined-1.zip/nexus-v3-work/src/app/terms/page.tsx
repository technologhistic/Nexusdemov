import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Terms & Conditions — Nexus Nepal",
  description:
    "Terms of use for the Nexus Nepal e-commerce platform under Nepal law.",
};

export default function TermsPage() {
  return (
    <div className="container" style={{ maxWidth: 800, padding: "48px 20px 80px" }}>
      <p style={{ fontSize: 13, color: "var(--slate)", marginBottom: 8 }}>
        <Link href="/" style={{ color: "var(--olive)" }}>
          Home
        </Link>{" "}
        / Terms &amp; Conditions
      </p>
      <h1 style={{ fontSize: 32, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 8 }}>
        Terms &amp; Conditions
      </h1>
      <p style={{ color: "var(--slate)", marginBottom: 32, fontSize: 14 }}>
        Last updated: 8 October 2026 · Governed by the laws of Nepal
      </p>

      <div style={{ lineHeight: 1.7, color: "var(--olive-deep)", fontSize: 15 }}>
        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>1. Operator</h2>
          <p>
            This platform is operated by <strong>[Legal Business Name]</strong>, registered at{" "}
            <strong>[Full Address]</strong>, PAN <strong>[Number]</strong>, DoCSCP Platform Listing
            Number <strong>[Number]</strong>. Contact: support@[domain] · [phone].
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>2. Acceptance</h2>
          <p>
            By accessing or placing an order on this platform you agree to these Terms, our{" "}
            <Link href="/privacy">Privacy Policy</Link>,{" "}
            <Link href="/refund">Refund &amp; Return Policy</Link> and{" "}
            <Link href="/cookies">Cookie Policy</Link>. If you do not agree, do not use the
            platform.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>3. Orders and contract formation</h2>
          <p>
            Placing an order constitutes an offer to purchase. We accept the offer by order
            confirmation and/or dispatch. We may refuse or cancel an order for stock unavailability,
            suspected fraud, pricing error, or legal reasons. In such cases any payment received
            will be refunded.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>4. Pricing and taxes</h2>
          <p>
            Prices displayed are the final selling price including applicable taxes unless expressly
            stated otherwise. Any delivery or additional charges are shown before you confirm the
            order. We reserve the right to correct obvious pricing errors.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>5. Product information</h2>
          <p>
            We aim to provide accurate descriptions, images, weight/dimensions, origin,
            warranty and other details required under the Electronic Commerce Act 2081. Images are
            illustrative. If goods do not match the disclosed description, your rights under the Act
            and the Consumer Protection Act 2075 apply (see Refund Policy).
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>6. Payment</h2>
          <p>
            We accept payment methods shown at checkout (e.g. eSewa, Khalti, bank transfer, Cash on
            Delivery). Payment to a delivery agent acting on our behalf is treated as payment to us.
            You must provide accurate payment and delivery information.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>7. Delivery</h2>
          <p>
            Estimated delivery times and any charges are shown on the product page and at checkout.
            Risk of loss generally passes on delivery according to the method chosen. Delays caused
            by events beyond our reasonable control will be communicated.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>8. Returns, refunds and cancellations</h2>
          <p>
            Please see our dedicated{" "}
            <Link href="/refund">Refund, Return &amp; Cancellation Policy</Link>, which is designed
            to comply with the strong buyer rights under the E-Commerce Act when goods do not match
            the description.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>9. Prohibited conduct</h2>
          <p>
            You must not: post fake reviews or ratings; misuse the return process; attempt to
            interfere with the security or integrity of the platform; use the platform for any
            unlawful purpose; or provide false information.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>10. Limitation of liability</h2>
          <p>
            To the maximum extent permitted by Nepali law, our liability arising from any order is
            limited to the amount paid for that order. Nothing in these Terms excludes liability that
            cannot be excluded under applicable consumer protection or other mandatory law.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>11. Governing law and disputes</h2>
          <p>
            These Terms are governed by the laws of Nepal. Disputes shall be subject to the
            jurisdiction of the competent courts of [your preferred district / Kathmandu]. You may
            also use our <Link href="/grievance">online grievance mechanism</Link>.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>12. Changes</h2>
          <p>
            We may update these Terms. The “Last updated” date will change. Continued use after
            changes constitutes acceptance of the updated Terms where permitted by law.
          </p>
        </section>
      </div>

      <div style={{ marginTop: 40, padding: 16, background: "rgba(184,242,53,0.12)", borderRadius: 12, fontSize: 13 }}>
        <strong>Demo note:</strong> Replace [bracketed] legal entity details before go-live. Have a
        Nepal-licensed lawyer review final wording.
      </div>
    </div>
  );
}

const h2: React.CSSProperties = {
  fontSize: 18,
  fontWeight: 700,
  color: "var(--olive-deep)",
  marginBottom: 10,
  marginTop: 4,
};
