import { clientIp, issueChallenge, rateLimit } from "@/lib/security";
import { json } from "@/lib/guard";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const ip = clientIp(req.headers);
  const rl = rateLimit(`challenge:${ip}`, 30, 60_000);
  if (!rl.ok) return json({ error: "Too many requests." }, 429, { "Retry-After": String(rl.retryAfterSec) });
  return json({ challenge: issueChallenge() });
}
