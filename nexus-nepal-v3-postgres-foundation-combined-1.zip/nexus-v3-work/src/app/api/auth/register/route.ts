import { createUser } from "@/lib/db";
import { guardPost, json } from "@/lib/guard";
import { checkPassword, cleanName, hashPassword, jitter, newId, normalizeEmail, rateLimit, sleep } from "@/lib/security";
import { startSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const g = await guardPost(req, { name: "register", limit: 5, windowMs: 60 * 60 * 1000 });
  if (g instanceof Response) return g;
  const { body } = g;

  const name = cleanName(body.name);
  const email = normalizeEmail(body.email);
  if (!name) return json({ error: "Enter your full name (2–60 characters)." }, 400);
  if (!email) return json({ error: "Enter a valid email address." }, 400);

  const pwError = checkPassword(body.password, email, name);
  if (pwError) return json({ error: pwError }, 400);
  if (body.password !== body.confirm) return json({ error: "Passwords do not match." }, 400);

  // Extra cap: one email can't be hammered from many IPs
  if (!rateLimit(`register:email:${email}`, 3, 60 * 60 * 1000).ok) {
    return json({ error: "Too many attempts. Please wait and try again." }, 429);
  }

  const passwordHash = await hashPassword(body.password as string);
  const id = newId();
  const created = await createUser({
    id,
    name,
    email,
    passwordHash,
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
    failedCount: 0,
    lockedUntil: 0,
  });

  if (!created) {
    await sleep(jitter(200, 500));
    return json({ error: "We couldn't create an account with those details. Try signing in instead." }, 409);
  }

  await startSession(id, true);
  return json({ ok: true, redirect: "/account" }, 201);
}
