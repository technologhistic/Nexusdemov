import { NextResponse } from "next/server";
import {
  buildAuthorizeUrl,
  createOAuthState,
  createPkce,
  getRedirectUri,
  isProviderConfigured,
  storePkceVerifier,
  type OAuthProvider,
} from "@/lib/oauth";
import { rateLimit, clientIp } from "@/lib/security";

export const dynamic = "force-dynamic";

const VALID: OAuthProvider[] = ["google", "facebook"];

export async function GET(
  req: Request,
  { params }: { params: Promise<{ provider: string }> }
) {
  const { provider: raw } = await params;
  const provider = raw.toLowerCase() as OAuthProvider;

  if (!VALID.includes(provider)) {
    return NextResponse.redirect(new URL("/login?error=unsupported", req.url));
  }

  if (!isProviderConfigured(provider)) {
    return NextResponse.redirect(new URL("/login?error=not_configured", req.url));
  }

  const ip = clientIp(req.headers);
  const rl = rateLimit(`oauth:start:${ip}`, 15, 10 * 60 * 1000);
  if (!rl.ok) {
    return NextResponse.redirect(new URL("/login?error=rate_limit", req.url));
  }

  const { verifier, challenge } = createPkce();
  const state = createOAuthState(provider, verifier);
  await storePkceVerifier(verifier);

  const redirectUri = getRedirectUri(provider, req);
  const url = buildAuthorizeUrl(provider, redirectUri, state, challenge);

  return NextResponse.redirect(url);
}
