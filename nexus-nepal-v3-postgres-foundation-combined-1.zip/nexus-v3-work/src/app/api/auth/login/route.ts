import { findUserByEmail, updateUser } from "@/lib/db";
import { guardPost, json } from "@/lib/guard";
import { burnPasswordCheck, jitter, normalizeEmail, rateLimit, sleep, verifyPassword } from "@/lib/security";
import { startSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const GENERIC = "Incorrect email or password.";
const MAX_FAILS = 5;

export async function POST(req: Request) {
  const g = await guardPost(req, { name: "login", limit: 10, windowMs: 10 * 60 * 1000 });
  if (g instanceof Response) return g;
  const { body } = g;

  const email = normalizeEmail(body.email);
  const password = typeof body.password === "string" && body.password.length <= 128 ? body.password : null;
  if (!email || !password) {
    await burnPasswordCheck(String(password ?? ""));
    await sleep(jitter(250, 550));
    return json({ error: GENERIC }, 401);
  }

  // Per-account throttle (stops distributed guessing against one victim)
  if (!rateLimit(`login:email:${email}`, 15, 15 * 60 * 1000).ok) {
    return json({ error: "Too many attempts. Please wait and try again." }, 429);
  }

  const user = await findUserByEmail(email);
  const now = Date.now();

  if (user && user.lockedUntil > now) {
    await burnPasswordCheck(password);
    const mins = Math.ceil((user.lockedUntil - now) / 60000);
    return json({ error: `Account temporarily locked. Try again in ${mins} minute${mins === 1 ? "" : "s"}.` }, 423);
  }

  let ok = false;
  if (user) {
    // OAuth-only accounts have empty passwordHash — force them to use social login
    if (!user.passwordHash) {
      await burnPasswordCheck(password);
      await sleep(jitter(250, 550));
      return json({ error: "This account uses social login. Please continue with Google or Facebook." }, 401);
    }
    ok = await verifyPassword(password, user.passwordHash);
  } else {
    await burnPasswordCheck(password);
  }

  if (!user || !ok) {
    if (user) {
      const fails = user.failedCount + 1;
      // 5 fails → 15 min lock, doubling for each further batch of 5 (max 6h)
      const lock =
        fails >= MAX_FAILS
          ? Math.min(15 * 60_000 * 2 ** Math.floor((fails - MAX_FAILS) / MAX_FAILS), 6 * 60 * 60_000)
          : 0;
      await updateUser(user.id, { failedCount: fails, lockedUntil: lock ? now + lock : 0 });
    }
    await sleep(jitter(250, 550));
    return json({ error: GENERIC }, 401);
  }

  await updateUser(user.id, { failedCount: 0, lockedUntil: 0, lastLoginAt: now });
  await startSession(user.id, body.remember === true);
  return json({ ok: true, redirect: "/account" });
}
