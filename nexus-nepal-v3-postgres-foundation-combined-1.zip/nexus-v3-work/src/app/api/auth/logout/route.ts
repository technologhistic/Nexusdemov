import { json } from "@/lib/guard";
import { sameOrigin } from "@/lib/security";
import { endSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!sameOrigin(req.headers)) return json({ error: "Request blocked." }, 403);
  await endSession();
  return json({ ok: true, redirect: "/login" });
}
