import { NextResponse } from "next/server";
import { createUser, findUserByEmail, updateUser } from "@/lib/db";
import {
  exchangeCode,
  fetchUserProfile,
  getRedirectUri,
  isProviderConfigured,
  parseOAuthState,
  takePkceVerifier,
  type OAuthProvider,
} from "@/lib/oauth";
import { clientIp, newId, rateLimit } from "@/lib/security";
import { startSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const VALID: OAuthProvider[] = ["google", "facebook"];

export async function GET(
  req: Request,
  { params }: { params: Promise<{ provider: string }> }
) {
  const { provider: raw } = await params;
  const provider = raw.toLowerCase() as OAuthProvider;
  const url = new URL(req.url);

  const fail = (code: string) =>
    NextResponse.redirect(new URL(`/login?error=${code}`, req.url));

  if (!VALID.includes(provider) || !isProviderConfigured(provider)) {
    return fail("unsupported");
  }

  const ip = clientIp(req.headers);
  const rl = rateLimit(`oauth:cb:${ip}`, 20, 10 * 60 * 1000);
  if (!rl.ok) return fail("rate_limit");

  const error = url.searchParams.get("error");
  if (error) return fail("denied");

  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  if (!code || !state) return fail("invalid");

  const parsed = parseOAuthState(state);
  if (!parsed.ok || parsed.provider !== provider) return fail("invalid_state");

  const verifier = await takePkceVerifier();
  if (!verifier) return fail("expired");

  const redirectUri = getRedirectUri(provider, req);
  const tokens = await exchangeCode(provider, code, redirectUri, verifier);
  if (!tokens) return fail("token");

  const profile = await fetchUserProfile(provider, tokens.access_token);
  if (!profile) return fail("profile");

  // Find or create user
  let user = await findUserByEmail(profile.email);
  const now = Date.now();

  if (!user) {
    const id = newId();
    const created = await createUser({
      id,
      name: profile.name.slice(0, 60),
      email: profile.email,
      passwordHash: "", // OAuth-only
      createdAt: now,
      lastLoginAt: now,
      failedCount: 0,
      lockedUntil: 0,
      oauthProvider: provider,
      oauthId: profile.id,
    });
    if (!created) return fail("exists");
    user = await findUserByEmail(profile.email);
  } else {
    // Link OAuth if not already linked
    await updateUser(user.id, {
      lastLoginAt: now,
      failedCount: 0,
      lockedUntil: 0,
      ...(user.oauthProvider ? {} : { oauthProvider: provider, oauthId: profile.id }),
    });
  }

  if (!user) return fail("server");

  await startSession(user.id, true); // remember by default for social
  return NextResponse.redirect(new URL("/account", req.url));
}
