import Link from "next/link";
import { products } from "@/data/products";
import ProductImage from "@/components/ProductImage";

function formatPrice(n: number) {
  return `NPR ${n.toLocaleString("en-NP")}`;
}

export default function HomePage() {
  const featured = products.slice(0, 6);

  return (
    <>
      {/* Hero */}
      <section
        style={{
          padding: "64px 0 48px",
          textAlign: "center",
        }}
      >
        <div className="container">
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              padding: "8px 16px",
              borderRadius: 20,
              background: "rgba(59,74,31,0.12)",
              color: "var(--olive)",
              fontSize: 13,
              fontWeight: 600,
              marginBottom: 20,
            }}
          >
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: "var(--lime)",
                display: "inline-block",
              }}
            />
            Authentic · Local · Fast Delivery
          </div>

          <h1
            style={{
              fontSize: "clamp(32px, 6vw, 52px)",
              lineHeight: 1.15,
              fontWeight: 800,
              color: "var(--olive-deep)",
              maxWidth: 720,
              margin: "0 auto 16px",
            }}
          >
            Discover the Best of{" "}
            <span
              style={{
                background: "linear-gradient(120deg, #232D0F, #6F8A2A 70%, #8FB02A)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Nepal
            </span>
          </h1>

          <p
            style={{
              fontSize: 17,
              color: "var(--slate)",
              maxWidth: 520,
              margin: "0 auto 32px",
            }}
          >
            From handwoven Dhaka and pure Ilam tea to trekking gear and sacred art — shop authentic Nepali products delivered to your door.
          </p>

          <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
            <Link href="/products" className="btn-primary">
              Shop All Products
              <span style={{ fontSize: 18 }}>→</span>
            </Link>
            <Link href="/categories" className="btn-lime">
              Browse Categories
            </Link>
          </div>
        </div>
      </section>
      {/* Compliance strip — visible to executives & customers */}
      <section
        style={{
          background: "linear-gradient(90deg, rgba(47,59,22,0.95), rgba(35,45,15,0.98))",
          color: "#F5EEDC",
          padding: "14px 0",
          borderTop: "1px solid rgba(184,242,53,0.25)",
          borderBottom: "1px solid rgba(184,242,53,0.25)",
        }}
      >
        <div
          className="container"
          style={{
            display: "flex",
            flexWrap: "wrap",
            alignItems: "center",
            justifyContent: "center",
            gap: "12px 28px",
            fontSize: 13,
            fontWeight: 500,
          }}
        >
          <span style={{ color: "#B8F235" }}>✓</span>
          <span>Nepal E-Commerce Act aligned</span>
          <span style={{ opacity: 0.4 }}>|</span>
          <a href="/privacy" style={{ color: "#F5EEDC" }}>Privacy Policy</a>
          <span style={{ opacity: 0.4 }}>|</span>
          <a href="/refund" style={{ color: "#F5EEDC" }}>Clear Refund Rights</a>
          <span style={{ opacity: 0.4 }}>|</span>
          <a href="/grievance" style={{ color: "#F5EEDC" }}>15-day Grievance Channel</a>
          <span style={{ opacity: 0.4 }}>|</span>
          <a href="/business" style={{ color: "#B8F235", fontWeight: 600 }}>Business &amp; Compliance Info</a>
        </div>
      </section>


      {/* Featured products */}
      <section style={{ padding: "24px 0 64px" }}>
        <div className="container">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", marginBottom: 28 }}>
            <div>
              <h2 style={{ fontSize: 28, fontWeight: 700, color: "var(--olive-deep)" }}>
                Featured Products
              </h2>
              <p style={{ color: "var(--slate)", marginTop: 4 }}>Hand-picked favourites from across Nepal</p>
            </div>
            <Link href="/products" style={{ color: "var(--olive)", fontWeight: 600, fontSize: 14 }}>
              View all →
            </Link>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
              gap: 24,
            }}
          >
            {featured.map((p) => (
              <Link
                key={p.id}
                href={`/products/${p.slug}`}
                className="card"
                style={{
                  overflow: "hidden",
                  transition: "transform 0.25s, box-shadow 0.25s",
                  display: "block",
                }}
              >
                <div style={{ position: "relative", aspectRatio: "1", background: "#e8e0c8" }}>
                  <ProductImage src={p.image} alt={p.name} />
                  {p.badge && (
                    <span
                      style={{
                        position: "absolute",
                        top: 12,
                        left: 12,
                        background: "var(--lime)",
                        color: "var(--olive-deep)",
                        fontSize: 11,
                        fontWeight: 700,
                        padding: "4px 10px",
                        borderRadius: 12,
                      }}
                    >
                      {p.badge}
                    </span>
                  )}
                </div>
                <div style={{ padding: 18 }}>
                  <div style={{ fontSize: 12, color: "var(--slate)", marginBottom: 4 }}>{p.category}</div>
                  <h3 style={{ fontSize: 16, fontWeight: 600, color: "var(--olive-deep)", marginBottom: 8 }}>
                    {p.name}
                  </h3>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontWeight: 700, fontSize: 17, color: "var(--olive)" }}>
                      {formatPrice(p.price)}
                    </span>
                    {p.originalPrice && (
                      <span style={{ fontSize: 13, color: "var(--slate)", textDecoration: "line-through" }}>
                        {formatPrice(p.originalPrice)}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Trust bar */}
      <section style={{ padding: "0 0 64px" }}>
        <div className="container">
          <div
            className="card"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: 24,
              padding: 28,
              textAlign: "center",
            }}
          >
            {[
              { title: "Authentic", desc: "Sourced from real Nepali artisans" },
              { title: "Fast Delivery", desc: "Across Kathmandu & major cities" },
              { title: "Secure Payment", desc: "eSewa · Khalti · Cards" },
              { title: "Easy Returns", desc: "7-day hassle-free policy" },
            ].map((item) => (
              <div key={item.title}>
                <div style={{ fontWeight: 700, color: "var(--olive-deep)", marginBottom: 4 }}>{item.title}</div>
                <div style={{ fontSize: 13, color: "var(--slate)" }}>{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
