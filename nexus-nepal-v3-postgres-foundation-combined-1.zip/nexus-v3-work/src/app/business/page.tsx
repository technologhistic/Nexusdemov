import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Business Information & Compliance — Nexus Nepal",
  description:
    "Legal entity details, DoCSCP listing, registration numbers and consumer contacts as required by Nepal’s Electronic Commerce Act 2081.",
};

export default function BusinessPage() {
  return (
    <div className="container" style={{ maxWidth: 800, padding: "48px 20px 80px" }}>
      <p style={{ fontSize: 13, color: "var(--slate)", marginBottom: 8 }}>
        <Link href="/" style={{ color: "var(--olive)" }}>
          Home
        </Link>{" "}
        / Business Information
      </p>
      <h1 style={{ fontSize: 32, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 8 }}>
        Business Information &amp; Compliance
      </h1>
      <p style={{ color: "var(--slate)", marginBottom: 32, fontSize: 14 }}>
        Disclosures required under the Electronic Commerce Act 2081 (Sections 4–6)
      </p>

      <div
        className="card"
        style={{
          padding: 28,
          marginBottom: 28,
          border: "1px solid rgba(59,74,31,0.12)",
        }}
      >
        <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 16, color: "var(--olive-deep)" }}>
          Legal entity
        </h2>
        <table style={{ width: "100%", fontSize: 14, borderCollapse: "collapse" }}>
          <tbody>
            {[
              ["Platform name", "Nexus Nepal"],
              ["Legal business name", "[Legal Business Name — to be filled]"],
              ["Registered address", "[Full registered address, Ward, Municipality, District]"],
              ["Registration authority", "[OCR / DoCSCP / other]"],
              ["Registration / Company No.", "[Number]"],
              ["PAN", "[Number]"],
              ["VAT (if registered)", "[Number or N/A]"],
              ["DoCSCP Platform Listing No.", "[Obtain before go-live — mandatory]"],
              ["Nature of business", "Direct seller of goods (physical & digital) via e-commerce"],
              ["Customer service", "support@nexusnepal.example · [phone]"],
              ["Grievance contact", "grievance@nexusnepal.example · Online form at /grievance"],
              ["Office / branches", "[List any additional outlets]"],
            ].map(([k, v]) => (
              <tr key={k} style={{ borderBottom: "1px solid rgba(59,74,31,0.08)" }}>
                <td style={{ padding: "10px 0", fontWeight: 600, width: "42%", color: "var(--olive-deep)" }}>
                  {k}
                </td>
                <td style={{ padding: "10px 0", color: "var(--slate)" }}>{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p style={{ fontSize: 13, color: "var(--slate)", marginTop: 16 }}>
          Any change to the above details will be updated on this platform within 48 hours as
          required by law.
        </p>
      </div>

      <div style={{ display: "grid", gap: 12, marginBottom: 32 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, color: "var(--olive-deep)" }}>Key policy links</h2>
        <Link href="/privacy" style={linkStyle}>
          Privacy Policy
        </Link>
        <Link href="/terms" style={linkStyle}>
          Terms &amp; Conditions
        </Link>
        <Link href="/refund" style={linkStyle}>
          Refund, Return &amp; Cancellation Policy
        </Link>
        <Link href="/cookies" style={linkStyle}>
          Cookie Policy
        </Link>
        <Link href="/grievance" style={linkStyle}>
          Online Grievance Redressal
        </Link>
      </div>

      <div
        style={{
          padding: 20,
          background: "linear-gradient(135deg, rgba(47,59,22,0.08), rgba(184,242,53,0.12))",
          borderRadius: 16,
          border: "1px solid rgba(59,74,31,0.12)",
        }}
      >
        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8, color: "var(--olive-deep)" }}>
          For CEO / CSO / Investors — Compliance posture (demo)
        </h3>
        <ul style={{ margin: 0, paddingLeft: 18, color: "var(--olive-deep)", fontSize: 14, lineHeight: 1.7 }}>
          <li>Mandatory DoCSCP e-commerce portal listing is the legal gate before real orders.</li>
          <li>Full business details and Platform Listing Number will be displayed publicly.</li>
          <li>Privacy, Terms, Refund and Cookie policies are live and Nepal-law aligned.</li>
          <li>Online grievance channel with 15-day target response is available.</li>
          <li>Product pages are structured for required disclosures (price incl. tax, delivery, warranty, origin).</li>
          <li>No real customer data or payments are processed until Phase-0 legal items are complete.</li>
        </ul>
      </div>
    </div>
  );
}

const linkStyle: React.CSSProperties = {
  display: "block",
  padding: "12px 16px",
  background: "rgba(245,238,220,0.5)",
  borderRadius: 10,
  color: "var(--olive-deep)",
  fontWeight: 600,
  fontSize: 14,
  border: "1px solid rgba(59,74,31,0.1)",
};
