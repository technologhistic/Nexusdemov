import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Refund, Return & Cancellation Policy — Nexus Nepal",
  description:
    "Buyer rights when goods do not match description, returns, refunds and cancellations under Nepal’s E-Commerce Act 2081 and Consumer Protection Act 2075.",
};

export default function RefundPage() {
  return (
    <div className="container" style={{ maxWidth: 800, padding: "48px 20px 80px" }}>
      <p style={{ fontSize: 13, color: "var(--slate)", marginBottom: 8 }}>
        <Link href="/" style={{ color: "var(--olive)" }}>
          Home
        </Link>{" "}
        / Refund &amp; Return Policy
      </p>
      <h1 style={{ fontSize: 32, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 8 }}>
        Refund, Return &amp; Cancellation Policy
      </h1>
      <p style={{ color: "var(--slate)", marginBottom: 32, fontSize: 14 }}>
        Last updated: 8 October 2026 · Aligned with Electronic Commerce Act 2081 §10 &amp; Consumer
        Protection Act 2075
      </p>

      <div style={{ lineHeight: 1.7, color: "var(--olive-deep)", fontSize: 15 }}>
        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>1. Goods that do not match the description (statutory right)</h2>
          <p>
            If the goods or services you receive do <strong>not match</strong> the description,
            image, weight, quality, warranty or other information disclosed on this platform, and
            the goods are unused and undamaged, you have the right to return them. Under the
            E-Commerce Act we must accept such a return without imposing unreasonable conditions.
          </p>
          <p>You may then choose:</p>
          <ul>
            <li>A replacement of equal value, or</li>
            <li>
              A <strong>full refund of the amount paid, including applicable taxes</strong>.
            </li>
          </ul>
          <p>
            This statutory right cannot be contracted away. We will process the return after
            verification of the item and the mismatch.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>2. Change-of-mind / additional return window</h2>
          <p>
            In addition to the statutory right above, for most products we offer a{" "}
            <strong>7-day return window</strong> from delivery for change of mind, provided the
            item is unused, undamaged, in original packaging where applicable, and with seals
            unbroken where the product is sealed. Some categories are excluded (see section 5).
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>3. Cancellation before dispatch</h2>
          <p>
            You may cancel an order before it is dispatched by contacting support or using your
            account order page. Once the order has been dispatched, the return rules above apply.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>4. How to request a return or refund</h2>
          <ol>
            <li>
              Submit a request via your account, the{" "}
              <Link href="/grievance">Grievance form</Link>, or email support@[domain] with order
              number and reason.
            </li>
            <li>We aim to acknowledge within 2 business days.</li>
            <li>
              Return the item as instructed (unused, undamaged). We may arrange pickup or provide a
              return address.
            </li>
            <li>
              After we receive and verify the item, we process the refund or replacement. Refunds
              are typically completed within 5–7 business days of verification and follow the
              original payment method where practicable (or bank transfer for COD).
            </li>
          </ol>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>5. Non-returnable items (subject to statutory rights)</h2>
          <p>
            The following are generally not returnable for change of mind (statutory “does not
            match description” rights still apply):
          </p>
          <ul>
            <li>Perishable goods (food, certain consumables)</li>
            <li>Opened hygiene or personal-care products</li>
            <li>Customised or made-to-order items</li>
            <li>Digital goods once delivered/accessed</li>
            <li>Items with broken seals where the seal is part of the product integrity</li>
          </ul>
          <p>
            These exclusions are consistent with limitations recognised under consumer protection
            principles; they do not override your rights when goods do not match the advertised
            description.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>6. Defective or damaged on arrival</h2>
          <p>
            If an item arrives damaged or is defective, contact us immediately with photos. We will
            arrange replacement or full refund (including tax) in accordance with the Act and this
            policy.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>7. Contact</h2>
          <p>
            Support: support@[domain] · Phone: [number]
            <br />
            Grievance: <Link href="/grievance">Online form</Link> or grievance@[domain]
            <br />
            We aim to resolve return and refund issues promptly and, for formal grievances, within
            15 days where practicable.
          </p>
        </section>
      </div>

      <div style={{ marginTop: 40, padding: 16, background: "rgba(184,242,53,0.12)", borderRadius: 12, fontSize: 13 }}>
        <strong>Demo note for leadership:</strong> This policy deliberately reflects the strong
        buyer rights under E-Commerce Act §10. Your operational process (warehouse, support SLAs)
        must match what is written here before go-live.
      </div>
    </div>
  );
}

const h2: React.CSSProperties = {
  fontSize: 18,
  fontWeight: 700,
  color: "var(--olive-deep)",
  marginBottom: 10,
  marginTop: 4,
};
