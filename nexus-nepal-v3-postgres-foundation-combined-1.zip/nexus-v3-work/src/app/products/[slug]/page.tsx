import Link from "next/link";
import { notFound } from "next/navigation";
import { getProductBySlug, products } from "@/data/products";
import ProductImage from "@/components/ProductImage";
import AddToCartButton from "@/components/AddToCartButton";

function formatPrice(n: number) {
  return `NPR ${n.toLocaleString("en-NP")}`;
}

function Stars({ rating }: { rating: number }) {
  const full = Math.floor(rating);
  const half = rating - full >= 0.5;
  return (
    <span style={{ color: "#E8A33D", letterSpacing: 1 }} aria-label={`${rating} out of 5`}>
      {"★".repeat(full)}
      {half ? "½" : ""}
      {"☆".repeat(5 - full - (half ? 1 : 0))}
    </span>
  );
}

export function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }));
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = getProductBySlug(slug);
  if (!product) notFound();

  const discount =
    product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : 0;

  return (
    <div className="container" style={{ padding: "32px 20px 64px" }}>
      <nav style={{ fontSize: 13, color: "var(--slate)", marginBottom: 20 }}>
        <Link href="/" style={{ color: "var(--olive)" }}>
          Home
        </Link>
        {" / "}
        <Link href="/products" style={{ color: "var(--olive)" }}>
          Products
        </Link>
        {" / "}
        <Link href={`/products?category=${encodeURIComponent(product.category)}`} style={{ color: "var(--olive)" }}>
          {product.category}
        </Link>
        {" / "}
        <span>{product.name}</span>
      </nav>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
          gap: 40,
          alignItems: "start",
        }}
      >
        <div className="card" style={{ aspectRatio: "1", overflow: "hidden", background: "#e8e0c8", position: "relative" }}>
          <ProductImage src={product.image} alt={product.name} priority />
          {product.badge && (
            <span
              style={{
                position: "absolute",
                top: 16,
                left: 16,
                background: "var(--lime)",
                color: "var(--olive-deep)",
                fontSize: 12,
                fontWeight: 700,
                padding: "6px 12px",
                borderRadius: 12,
              }}
            >
              {product.badge}
            </span>
          )}
        </div>

        <div>
          <div style={{ fontSize: 13, color: "var(--slate)", marginBottom: 6 }}>
            {product.brand} · {product.category}
            {product.subcategory ? ` · ${product.subcategory}` : ""}
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 10, lineHeight: 1.25 }}>
            {product.name}
          </h1>

          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
            <Stars rating={product.rating} />
            <span style={{ fontWeight: 600 }}>{product.rating.toFixed(1)}</span>
            <span style={{ color: "var(--slate)", fontSize: 14 }}>
              ({product.reviewCount.toLocaleString()} reviews)
            </span>
            <span style={{ color: "var(--slate)" }}>·</span>
            <span style={{ fontSize: 14, color: "var(--olive)" }}>{product.sold.toLocaleString()} sold</span>
          </div>

          <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 4 }}>
            <span style={{ fontSize: 30, fontWeight: 800, color: "var(--olive)" }}>{formatPrice(product.price)}</span>
            {product.originalPrice && (
              <>
                <span style={{ fontSize: 16, color: "var(--slate)", textDecoration: "line-through" }}>
                  {formatPrice(product.originalPrice)}
                </span>
                {discount > 0 && (
                  <span
                    style={{
                      background: "#FDECEA",
                      color: "#8A1C12",
                      fontSize: 13,
                      fontWeight: 700,
                      padding: "2px 8px",
                      borderRadius: 8,
                    }}
                  >
                    -{discount}%
                  </span>
                )}
              </>
            )}
          </div>
          <p style={{ fontSize: 12, color: "var(--slate)", marginBottom: 12 }}>
            Final price inclusive of applicable taxes · Delivery charges shown at checkout
          </p>

          {product.inStock ? (
            <p style={{ color: "#2E7D32", fontWeight: 600, fontSize: 14, marginBottom: 20 }}>
              In stock{product.stockCount ? ` · ${product.stockCount} left` : ""}
            </p>
          ) : (
            <p style={{ color: "#C62828", fontWeight: 600, fontSize: 14, marginBottom: 20 }}>Out of stock</p>
          )}

          <p style={{ color: "var(--slate)", lineHeight: 1.65, marginBottom: 24 }}>{product.description}</p>

          {product.highlights && product.highlights.length > 0 && (
            <ul style={{ marginBottom: 24, paddingLeft: 18, color: "var(--olive-deep)" }}>
              {product.highlights.map((h) => (
                <li key={h} style={{ marginBottom: 6 }}>
                  {h}
                </li>
              ))}
            </ul>
          )}

          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 28 }}>
            <AddToCartButton productId={product.id} disabled={!product.inStock} />
            <Link href="/checkout" className="btn-lime" style={{ display: "inline-flex", alignItems: "center", padding: "0 24px", height: 48, borderRadius: 24, fontWeight: 600 }}>
              Buy Now
            </Link>
          </div>

          <div style={{ fontSize: 13, color: "var(--slate)", display: "grid", gap: 6, marginBottom: 16 }}>
            {product.warranty && <div>🛡 Warranty / Return: {product.warranty}</div>}
            {product.delivery && <div>🚚 Delivery: {product.delivery} across Nepal</div>}
            {product.seller && <div>🏪 Sold by: {product.seller}</div>}
            <div>📦 Origin: Nepal (unless otherwise stated in specifications)</div>
            <div>
              ↩️ Returns: If goods do not match the description you may return unused/undamaged items for
              replacement or full refund incl. tax — see{" "}
              <a href="/refund" style={{ color: "var(--olive)", fontWeight: 600 }}>Refund Policy</a>
            </div>
          </div>
        </div>
      </div>

      {/* Specifications table — Daraz style */}
      <section style={{ marginTop: 48 }}>
        <h2 style={{ fontSize: 22, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 16 }}>
          Specifications
        </h2>
        <div
          className="card"
          style={{
            overflow: "hidden",
            border: "1px solid rgba(59,74,31,0.12)",
          }}
        >
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <tbody>
              {product.specs.map((s, i) => (
                <tr key={s.label} style={{ background: i % 2 === 0 ? "rgba(245,238,220,0.4)" : "transparent" }}>
                  <td
                    style={{
                      padding: "12px 16px",
                      fontWeight: 600,
                      color: "var(--olive-deep)",
                      width: "40%",
                      borderBottom: "1px solid rgba(59,74,31,0.08)",
                    }}
                  >
                    {s.label}
                  </td>
                  <td
                    style={{
                      padding: "12px 16px",
                      color: "var(--slate)",
                      borderBottom: "1px solid rgba(59,74,31,0.08)",
                    }}
                  >
                    {s.value}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
