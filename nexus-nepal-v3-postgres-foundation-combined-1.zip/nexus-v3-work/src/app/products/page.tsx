import { products, categories } from "@/data/products";
import ProductsBrowser from "@/components/ProductsBrowser";

export const metadata = {
  title: "Shop — Nexus Nepal",
  description: "Browse authentic Nepali products, electronics, fashion, beauty and more.",
};

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;

  return (
    <div className="container" style={{ padding: "40px 20px 64px" }}>
      <h1 style={{ fontSize: 32, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 8 }}>
        Shop
      </h1>
      <p style={{ color: "var(--slate)", marginBottom: 24 }}>
        {products.length}+ products · Authentic Nepali + Tech · Daraz-style selection
      </p>

      <ProductsBrowser
        products={products}
        categories={categories}
        initialCategory={category || ""}
      />
    </div>
  );
}
