"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCart } from "@/lib/cart";

function formatPrice(n: number) {
  return `NPR ${n.toLocaleString("en-NP")}`;
}

type PayMethod = "esewa" | "khalti" | "bank" | "cod";

const METHODS: { id: PayMethod; title: string; desc: string }[] = [
  { id: "esewa", title: "eSewa", desc: "Pay securely with eSewa wallet" },
  { id: "khalti", title: "Khalti", desc: "Pay with Khalti digital wallet" },
  { id: "bank", title: "Online Banking / Bank Transfer", desc: "Direct bank transfer or online banking" },
  { id: "cod", title: "Cash on Delivery", desc: "Pay cash when your order arrives" },
];

export default function CheckoutPage() {
  const { lines, subtotal, clear, count } = useCart();
  const router = useRouter();
  const [method, setMethod] = useState<PayMethod>("cod");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("Kathmandu");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [orderId, setOrderId] = useState("");

  const delivery = subtotal >= 3000 ? 0 : 150;
  const total = subtotal + delivery;

  if (count === 0 && !done) {
    return (
      <div className="container" style={{ padding: "48px 20px", textAlign: "center" }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: "var(--olive-deep)" }}>Checkout</h1>
        <p style={{ color: "var(--slate)", margin: "16px 0 28px" }}>Your cart is empty.</p>
        <Link href="/products" className="btn-primary">
          Shop now
        </Link>
      </div>
    );
  }

  if (done) {
    return (
      <div className="container" style={{ padding: "48px 20px", maxWidth: 520, textAlign: "center" }}>
        <div
          style={{
            width: 72,
            height: 72,
            borderRadius: 36,
            background: "var(--lime)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "0 auto 20px",
            fontSize: 32,
          }}
        >
          ✓
        </div>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 8 }}>
          Order placed!
        </h1>
        <p style={{ color: "var(--slate)", marginBottom: 8 }}>
          Order ID: <strong>{orderId}</strong>
        </p>
        <p style={{ color: "var(--slate)", marginBottom: 28 }}>
          {method === "cod"
            ? "Pay cash when your order arrives. We will call to confirm."
            : method === "bank"
              ? "Please transfer the amount and keep the receipt. We will verify and process."
              : `You selected ${method === "esewa" ? "eSewa" : "Khalti"}. Complete payment in the wallet (demo — no real charge).`}
        </p>
        <Link href="/products" className="btn-primary">
          Continue shopping
        </Link>
      </div>
    );
  }

  async function placeOrder(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    if (!name.trim() || !phone.trim() || !address.trim()) return;
    setBusy(true);

    // Demo: simulate payment gateway redirect / processing
    await new Promise((r) => setTimeout(r, 900));

    const id = "NX" + Date.now().toString(36).toUpperCase();
    setOrderId(id);
    clear();
    setDone(true);
    setBusy(false);
  }

  return (
    <div className="container" style={{ padding: "32px 20px 64px" }}>
      <h1 style={{ fontSize: 28, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 24 }}>Checkout</h1>

      <form
        onSubmit={placeOrder}
        style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 32, alignItems: "start" }}
        className="checkout-grid"
      >
        <div style={{ display: "grid", gap: 24 }}>
          {/* Shipping */}
          <section className="card" style={{ padding: 24 }}>
            <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Delivery details</h2>
            <div style={{ display: "grid", gap: 14 }}>
              <label style={{ display: "grid", gap: 6 }}>
                <span style={{ fontSize: 13, fontWeight: 500 }}>Full name</span>
                <input
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="nx-input-plain"
                  placeholder="Your full name"
                />
              </label>
              <label style={{ display: "grid", gap: 6 }}>
                <span style={{ fontSize: 13, fontWeight: 500 }}>Phone (Nepal)</span>
                <input
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="nx-input-plain"
                  placeholder="98XXXXXXXX"
                  inputMode="tel"
                />
              </label>
              <label style={{ display: "grid", gap: 6 }}>
                <span style={{ fontSize: 13, fontWeight: 500 }}>Address</span>
                <textarea
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="nx-input-plain"
                  rows={3}
                  placeholder="Street, area, landmark"
                />
              </label>
              <label style={{ display: "grid", gap: 6 }}>
                <span style={{ fontSize: 13, fontWeight: 500 }}>City / District</span>
                <input
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="nx-input-plain"
                  placeholder="Kathmandu"
                />
              </label>
              <label style={{ display: "grid", gap: 6 }}>
                <span style={{ fontSize: 13, fontWeight: 500 }}>Order note (optional)</span>
                <input
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="nx-input-plain"
                  placeholder="e.g. Call before delivery"
                />
              </label>
            </div>
          </section>

          {/* Payment methods */}
          <section className="card" style={{ padding: 24 }}>
            <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Payment method</h2>
            <div style={{ display: "grid", gap: 10 }}>
              {METHODS.map((m) => (
                <label
                  key={m.id}
                  style={{
                    display: "flex",
                    gap: 14,
                    alignItems: "flex-start",
                    padding: "14px 16px",
                    borderRadius: 14,
                    border: method === m.id ? "2px solid var(--olive)" : "1px solid rgba(59,74,31,0.15)",
                    background: method === m.id ? "rgba(184,242,39,0.12)" : "#fff",
                    cursor: "pointer",
                  }}
                >
                  <input
                    type="radio"
                    name="pay"
                    checked={method === m.id}
                    onChange={() => setMethod(m.id)}
                    style={{ marginTop: 4 }}
                  />
                  <div>
                    <div style={{ fontWeight: 700, color: "var(--olive-deep)" }}>{m.title}</div>
                    <div style={{ fontSize: 13, color: "var(--slate)" }}>{m.desc}</div>
                  </div>
                </label>
              ))}
            </div>

            {method === "bank" && (
              <div
                style={{
                  marginTop: 16,
                  padding: 14,
                  borderRadius: 12,
                  background: "rgba(59,74,31,0.06)",
                  fontSize: 13,
                  color: "var(--olive-deep)",
                }}
              >
                <strong>Bank details (demo):</strong>
                <br />
                Nexus Nepal Pvt. Ltd.
                <br />
                Account: 0123456789012345 · Nabil Bank
                <br />
                Use Order ID as payment reference after placing order.
              </div>
            )}
          </section>
        </div>

        {/* Summary */}
        <div className="card" style={{ padding: 24, position: "sticky", top: 96 }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Order summary</h2>
          <div style={{ display: "grid", gap: 8, marginBottom: 16, fontSize: 14 }}>
            {lines.map(({ product, qty, lineTotal }) => (
              <div key={product.id} style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
                <span style={{ color: "var(--slate)" }}>
                  {product.name} × {qty}
                </span>
                <span style={{ fontWeight: 600 }}>{formatPrice(lineTotal)}</span>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 14 }}>
            <span style={{ color: "var(--slate)" }}>Subtotal</span>
            <span>{formatPrice(subtotal)}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12, fontSize: 14 }}>
            <span style={{ color: "var(--slate)" }}>Delivery</span>
            <span>{delivery === 0 ? "Free" : formatPrice(delivery)}</span>
          </div>
          <div
            style={{
              borderTop: "1px solid rgba(59,74,31,0.12)",
              paddingTop: 12,
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 20,
            }}
          >
            <span style={{ fontWeight: 700 }}>Total</span>
            <span style={{ fontWeight: 800, fontSize: 20, color: "var(--olive)" }}>{formatPrice(total)}</span>
          </div>
          <label style={{ display: "flex", gap: 10, alignItems: "flex-start", fontSize: 12.5, lineHeight: 1.45, color: "var(--olive-deep)", marginBottom: 12 }}>
            <input type="checkbox" name="checkout_consent" required style={{ marginTop: 3, flexShrink: 0 }} />
            <span>
              I agree to the{" "}
              <a href="/terms" style={{ color: "var(--olive)", fontWeight: 600 }}>Terms</a>,{" "}
              <a href="/privacy" style={{ color: "var(--olive)", fontWeight: 600 }}>Privacy Policy</a>{" "}
              and{" "}
              <a href="/refund" style={{ color: "var(--olive)", fontWeight: 600 }}>Refund Policy</a>.
              I consent to processing of my order and delivery data solely for fulfilment and support.
            </span>
          </label>
          <button
            type="submit"
            className="btn-primary"
            disabled={busy}
            style={{ width: "100%", height: 50, borderRadius: 25, opacity: busy ? 0.7 : 1 }}
          >
            {busy ? "Processing…" : method === "cod" ? "Place Order (COD)" : `Pay with ${METHODS.find((m) => m.id === method)?.title}`}
          </button>
          <p style={{ fontSize: 12, color: "var(--slate)", marginTop: 12, textAlign: "center" }}>
            Demo checkout — no real money is charged. Production will use NRB-approved gateways with
            verified callbacks and no double-charge risk.
          </p>
          <p style={{ fontSize: 11, color: "var(--slate)", marginTop: 6, textAlign: "center" }}>
            Prices shown are final and inclusive of applicable taxes. See{" "}
            <a href="/grievance" style={{ color: "var(--olive)" }}>Grievance</a> if something goes wrong.
          </p>
        </div>
      </form>

      <style jsx global>{`
        .nx-input-plain {
          width: 100%;
          height: 48px;
          padding: 0 14px;
          border: 1px solid rgba(59, 74, 31, 0.18);
          border-radius: 12px;
          background: rgba(245, 238, 220, 0.45);
          font: inherit;
          font-size: 15px;
        }
        textarea.nx-input-plain {
          height: auto;
          padding: 12px 14px;
          resize: vertical;
        }
        .nx-input-plain:focus {
          outline: none;
          border-color: var(--olive);
          box-shadow: 0 0 0 3px rgba(184, 242, 39, 0.4);
        }
        @media (max-width: 800px) {
          .checkout-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
