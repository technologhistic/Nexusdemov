import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Providers from "@/components/Providers";
import CookieConsent from "@/components/CookieConsent";
import { getCurrentUser } from "@/lib/session";

export const metadata: Metadata = {
  title: "Nexus Nepal — Authentic Nepali Products & Tech",
  description:
    "Shop authentic Nepali handicrafts, tea, trekking gear, fashion, electronics and more. Pay with eSewa, Khalti, bank transfer or Cash on Delivery. Registered e-commerce platform aligned with Nepal law.",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <Providers>
          <Header user={user ? { name: user.name } : null} />
          <main style={{ minHeight: "calc(100vh - 72px)" }}>{children}</main>
          <footer
            style={{
              background: "linear-gradient(135deg, #2F3B16, #232D0F)",
              color: "#F5EEDC",
              padding: "48px 0 32px",
              marginTop: 60,
            }}
          >
            <div className="container" style={{ display: "grid", gap: 32 }}>
              <div
                style={{
                  display: "flex",
                  flexWrap: "wrap",
                  justifyContent: "space-between",
                  gap: 24,
                }}
              >
                <div>
                  <div style={{ fontWeight: 800, fontSize: 20, color: "#B8F235", marginBottom: 8 }}>
                    Nexus Nepal
                  </div>
                  <p style={{ color: "rgba(245,238,220,0.75)", maxWidth: 300, fontSize: 14, lineHeight: 1.5 }}>
                    Authentic Nepali products + modern tech. Fair prices, reliable delivery across
                    Nepal.
                  </p>
                  <p style={{ color: "rgba(245,238,220,0.55)", fontSize: 12, marginTop: 12, maxWidth: 300 }}>
                    [Legal Business Name] · PAN [Number] · DoCSCP Listing [Number]
                    <br />
                    [Registered address]
                  </p>
                </div>
                <div style={{ display: "flex", gap: 40, flexWrap: "wrap" }}>
                  <div>
                    <div style={{ fontWeight: 600, marginBottom: 12 }}>Shop</div>
                    <div
                      style={{
                        display: "grid",
                        gap: 8,
                        fontSize: 14,
                        color: "rgba(245,238,220,0.8)",
                      }}
                    >
                      <a href="/products">All Products</a>
                      <a href="/products?category=Electronics">Electronics</a>
                      <a href="/products?category=Fashion">Fashion</a>
                    </div>
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, marginBottom: 12 }}>Legal &amp; Support</div>
                    <div
                      style={{
                        display: "grid",
                        gap: 8,
                        fontSize: 14,
                        color: "rgba(245,238,220,0.8)",
                      }}
                    >
                      <a href="/business">Business Information</a>
                      <a href="/privacy">Privacy Policy</a>
                      <a href="/terms">Terms &amp; Conditions</a>
                      <a href="/refund">Refund &amp; Returns</a>
                      <a href="/cookies">Cookie Policy</a>
                      <a href="/grievance">Grievance Redressal</a>
                    </div>
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, marginBottom: 12 }}>Payments</div>
                    <div
                      style={{
                        display: "grid",
                        gap: 8,
                        fontSize: 14,
                        color: "rgba(245,238,220,0.8)",
                      }}
                    >
                      <span>eSewa · Khalti</span>
                      <span>Online Banking</span>
                      <span>Cash on Delivery</span>
                    </div>
                  </div>
                </div>
              </div>
              <div
                style={{
                  borderTop: "1px solid rgba(184,242,39,0.2)",
                  paddingTop: 20,
                  fontSize: 12,
                  color: "rgba(245,238,220,0.55)",
                  display: "flex",
                  flexWrap: "wrap",
                  justifyContent: "space-between",
                  gap: 12,
                }}
              >
                <span>© {new Date().getFullYear()} Nexus Nepal. All rights reserved.</span>
                <span>
                  Prices include applicable taxes · Governed by the laws of Nepal ·{" "}
                  <a href="/business" style={{ color: "#B8F235" }}>
                    Compliance
                  </a>
                </span>
              </div>
            </div>
          </footer>
          <CookieConsent />
        </Providers>
      </body>
    </html>
  );
}
