import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Cookie Policy — Nexus Nepal",
  description: "How Nexus Nepal uses cookies and similar technologies.",
};

export default function CookiesPage() {
  return (
    <div className="container" style={{ maxWidth: 800, padding: "48px 20px 80px" }}>
      <p style={{ fontSize: 13, color: "var(--slate)", marginBottom: 8 }}>
        <Link href="/" style={{ color: "var(--olive)" }}>
          Home
        </Link>{" "}
        / Cookie Policy
      </p>
      <h1 style={{ fontSize: 32, fontWeight: 800, color: "var(--olive-deep)", marginBottom: 8 }}>
        Cookie Policy
      </h1>
      <p style={{ color: "var(--slate)", marginBottom: 32, fontSize: 14 }}>
        Last updated: 8 October 2026
      </p>

      <div style={{ lineHeight: 1.7, color: "var(--olive-deep)", fontSize: 15 }}>
        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>1. What are cookies?</h2>
          <p>
            Cookies are small text files stored on your device when you visit a website. They help
            the site remember your actions and preferences and keep you signed in securely.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>2. How we use cookies</h2>
          <p>
            <strong>Essential cookies (always active)</strong> — required for the platform to
            function: session authentication, shopping cart, security (CSRF / rate-limit tokens),
            and load balancing. These cannot be switched off without breaking core features.
          </p>
          <p>
            <strong>Optional / analytics cookies</strong> — used only if you consent via the cookie
            banner. They help us understand how the site is used so we can improve it. We do not
            currently run advertising cookies.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>3. Consent</h2>
          <p>
            When you first visit, a banner asks for your preference. Essential cookies load
            automatically. Non-essential cookies are set only after you accept. You can change your
            mind later by clearing cookies in your browser or contacting us.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>4. Third parties</h2>
          <p>
            Payment gateways (eSewa, Khalti, etc.) and delivery partners may set their own cookies
            when you interact with their systems. Those are governed by their respective policies.
          </p>
        </section>

        <section style={{ marginBottom: 28 }}>
          <h2 style={h2}>5. More information</h2>
          <p>
            See our <Link href="/privacy">Privacy Policy</Link> for how personal data is handled.
            Questions: privacy@[domain].
          </p>
        </section>
      </div>
    </div>
  );
}

const h2: React.CSSProperties = {
  fontSize: 18,
  fontWeight: 700,
  color: "var(--olive-deep)",
  marginBottom: 10,
  marginTop: 4,
};
