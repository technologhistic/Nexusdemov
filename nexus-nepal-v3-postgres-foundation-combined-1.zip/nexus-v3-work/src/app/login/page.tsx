import { Suspense } from "react";
import { redirect } from "next/navigation";
import AuthForm from "@/components/AuthForm";
import { getCurrentUser } from "@/lib/session";

export const metadata = { title: "Sign in — Nexus Nepal", robots: { index: false } };

export default async function LoginPage() {
  if (await getCurrentUser()) redirect("/account");
  return (
    <Suspense fallback={<div className="nx-auth"><div className="nx-wrap">Loading…</div></div>}>
      <AuthForm mode="login" />
    </Suspense>
  );
}
