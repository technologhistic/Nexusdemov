"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

const KEY = "nx_cookie_consent";

export default function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      if (!localStorage.getItem(KEY)) setVisible(true);
    } catch {
      setVisible(true);
    }
  }, []);

  function accept() {
    try {
      localStorage.setItem(KEY, "accepted");
    } catch {
      /* ignore */
    }
    setVisible(false);
  }

  function essentialOnly() {
    try {
      localStorage.setItem(KEY, "essential");
    } catch {
      /* ignore */
    }
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-label="Cookie consent"
      style={{
        position: "fixed",
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 9999,
        background: "linear-gradient(135deg, #2F3B16, #232D0F)",
        color: "#F5EEDC",
        padding: "16px 20px",
        boxShadow: "0 -4px 24px rgba(0,0,0,0.25)",
      }}
    >
      <div
        className="container"
        style={{
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 16,
        }}
      >
        <p style={{ margin: 0, fontSize: 14, lineHeight: 1.5, maxWidth: 640 }}>
          We use essential cookies to keep you signed in, remember your cart and protect the site.
          Optional analytics cookies are used only if you accept.{" "}
          <Link href="/cookies" style={{ color: "#B8F235", textDecoration: "underline" }}>
            Cookie Policy
          </Link>
          {" · "}
          <Link href="/privacy" style={{ color: "#B8F235", textDecoration: "underline" }}>
            Privacy
          </Link>
        </p>
        <div style={{ display: "flex", gap: 10, flexShrink: 0 }}>
          <button
            type="button"
            onClick={essentialOnly}
            style={{
              height: 40,
              padding: "0 16px",
              borderRadius: 20,
              border: "1px solid rgba(245,238,220,0.35)",
              background: "transparent",
              color: "#F5EEDC",
              fontWeight: 600,
              fontSize: 13,
              cursor: "pointer",
            }}
          >
            Essential only
          </button>
          <button
            type="button"
            onClick={accept}
            className="btn-lime"
            style={{ height: 40, padding: "0 20px", borderRadius: 20, fontSize: 13 }}
          >
            Accept all
          </button>
        </div>
      </div>
    </div>
  );
}
