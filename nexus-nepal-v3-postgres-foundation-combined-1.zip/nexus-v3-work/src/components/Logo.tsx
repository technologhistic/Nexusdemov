"use client";

import Image from "next/image";
import Link from "next/link";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
  className?: string;
}

export default function Logo({ size = "md", className = "" }: LogoProps) {
  const heights = { sm: 36, md: 48, lg: 72 };
  const h = heights[size];

  return (
    <Link href="/" className={`logo-animated inline-flex items-center ${className}`} aria-label="Nexus Nepal Home">
      <Image
        src="/logo.png"
        alt="Nexus Nepal"
        width={h * 3.2}
        height={h}
        priority
        style={{ height: h, width: "auto", objectFit: "contain" }}
        className="logo-speed-lines"
      />
    </Link>
  );
}
