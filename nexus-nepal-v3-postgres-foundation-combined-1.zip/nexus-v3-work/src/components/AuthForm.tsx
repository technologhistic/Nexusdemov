"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import "@/app/auth.css";

type Mode = "login" | "register";
type Provider = "email" | "Facebook" | "Instagram" | "Twitter" | "Google";

const SITE_KEY = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY;
const MIN_WAIT_MS = 2200;

// Which social providers are actually wired for OAuth (must match env vars)
const OAUTH_READY = new Set(
  [
    process.env.NEXT_PUBLIC_GOOGLE_ENABLED === "1" ? "Google" : null,
    process.env.NEXT_PUBLIC_FACEBOOK_ENABLED === "1" ? "Facebook" : null,
  ].filter(Boolean) as Provider[]
);

type TurnstileApi = {
  render: (el: HTMLElement, opts: { sitekey: string; callback: (t: string) => void; "expired-callback": () => void }) => string;
  reset: (id?: string) => void;
};
declare global {
  interface Window {
    turnstile?: TurnstileApi;
  }
}

const ICONS: Record<Provider, React.ReactNode> = {
  email: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" aria-hidden="true">
      <rect x="3" y="5" width="18" height="14" rx="3" />
      <path d="m4 8 8 6 8-6" />
    </svg>
  ),
  Facebook: (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M14 8.5V7c0-.8.2-1.2 1.3-1.2H17V3h-2.4C12 3 10.6 4.5 10.6 6.8v1.7H8.5v3h2.1V21H14v-9.5h2.4l.4-3z" />
    </svg>
  ),
  Instagram: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none" />
    </svg>
  ),
  Twitter: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" aria-hidden="true">
      <path d="M5 4.5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-7l-5 4v-4H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2z" />
    </svg>
  ),
  Google: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M19 7.5A8 8 0 1 0 20 12h-7.5" />
    </svg>
  ),
};

const TABS: { id: Provider; label: string; radio: string }[] = [
  { id: "email", label: "Email", radio: "p-email" },
  { id: "Facebook", label: "Facebook", radio: "p-fb" },
  { id: "Instagram", label: "Instagram", radio: "p-ig" },
  { id: "Twitter", label: "Twitter", radio: "p-tw" },
  { id: "Google", label: "Google", radio: "p-gg" },
];

const ERROR_MESSAGES: Record<string, string> = {
  unsupported: "That login method is not available.",
  not_configured: "Social login is not configured yet.",
  rate_limit: "Too many attempts. Please wait a moment.",
  denied: "You cancelled the social login.",
  invalid: "Invalid response from the provider.",
  invalid_state: "Security check failed. Please try again.",
  expired: "Login session expired. Please try again.",
  token: "Could not complete social login. Please try again.",
  profile: "Could not read your profile. Make sure email permission is granted.",
  exists: "An account with that email already exists.",
  server: "Something went wrong. Please try again.",
};

function strength(pw: string): number {
  if (!pw) return 0;
  let s = 0;
  if (pw.length >= 12) s++;
  if (pw.length >= 16) s++;
  if ([/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/].filter((r) => r.test(pw)).length >= 3) s++;
  if (pw.length >= 12 && new Set(pw).size >= 8) s++;
  return Math.min(s, 4);
}

export default function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const isLogin = mode === "login";

  const [provider, setProvider] = useState<Provider>("email");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const [challenge, setChallenge] = useState<string | null>(null);
  const issuedAt = useRef(0);
  const honeypot = useRef<HTMLInputElement>(null);

  const [tsToken, setTsToken] = useState("");
  const tsBox = useRef<HTMLDivElement>(null);
  const tsId = useRef<string | undefined>(undefined);

  // Surface OAuth errors from query string
  useEffect(() => {
    const err = searchParams.get("error");
    if (err && ERROR_MESSAGES[err]) {
      setError(ERROR_MESSAGES[err]);
    }
  }, [searchParams]);

  const loadChallenge = useCallback(async () => {
    setChallenge(null);
    try {
      const res = await fetch("/api/auth/challenge", { cache: "no-store", credentials: "same-origin" });
      if (!res.ok) throw new Error();
      const data = (await res.json()) as { challenge: string };
      issuedAt.current = Date.now();
      setChallenge(data.challenge);
    } catch {
      setError("Couldn't start a secure session. Check your connection and refresh.");
    }
  }, []);

  useEffect(() => {
    void loadChallenge();
  }, [loadChallenge]);

  // Optional Cloudflare Turnstile
  useEffect(() => {
    if (!SITE_KEY || !tsBox.current) return;
    const mount = () => {
      if (!window.turnstile || !tsBox.current || tsId.current) return;
      tsId.current = window.turnstile.render(tsBox.current, {
        sitekey: SITE_KEY,
        callback: setTsToken,
        "expired-callback": () => setTsToken(""),
      });
    };
    if (window.turnstile) {
      mount();
    } else {
      const s = document.createElement("script");
      s.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
      s.async = true;
      s.onload = mount;
      document.head.appendChild(s);
    }
    return () => {
      tsId.current = undefined;
    };
  }, [provider]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (busy || !challenge) return;
    setError("");

    if (!isLogin && password !== confirm) {
      setError("Passwords do not match.");
      return;
    }

    setBusy(true);

    const wait = MIN_WAIT_MS - (Date.now() - issuedAt.current);
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));

    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        cache: "no-store",
        body: JSON.stringify({
          ...(isLogin ? { remember } : { name, confirm }),
          email,
          password,
          challenge,
          website: honeypot.current?.value ?? "",
          turnstile: tsToken,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; redirect?: string };
      if (res.ok && data.redirect) {
        router.push(data.redirect);
        router.refresh();
        return;
      }
      setError(data.error || "Something went wrong. Please try again.");
      setPassword("");
      setConfirm("");
    } catch {
      setError("Network error. Please try again.");
    }
    if (window.turnstile && tsId.current) window.turnstile.reset(tsId.current);
    setTsToken("");
    setBusy(false);
    void loadChallenge();
  }

  function startOAuth(p: Provider) {
    const map: Record<string, string> = { Google: "google", Facebook: "facebook" };
    const slug = map[p];
    if (!slug) return;
    setBusy(true);
    window.location.href = `/api/auth/oauth/${slug}`;
  }

  const social = provider !== "email";
  const oauthReady = OAUTH_READY.has(provider);
  const s = strength(password);
  const ready = !!challenge && (!SITE_KEY || !!tsToken);

  return (
    <div className="nx-auth">
      <main className="nx-wrap">
        {/* Hidden radios — pure CSS tab switching exactly like the original HTML */}
        {isLogin &&
          TABS.map((t) => (
            <input
              key={t.radio}
              className="nx-sr"
              type="radio"
              name="provider"
              id={t.radio}
              checked={provider === t.id}
              onChange={() => {
                setProvider(t.id);
                setError("");
              }}
            />
          ))}

        <div className="nx-head">
          <div className="nx-mark" aria-hidden="true">
            N
          </div>
          <h1 className="nx-h1">{isLogin ? "Welcome back to Nexus Nepal" : "Create your Nexus Nepal account"}</h1>
          <p className="nx-sub">
            {isLogin ? (
              social ? (
                <span className="nx-anim">Continue with {provider} to access your account.</span>
              ) : (
                <span className="nx-anim">Sign in with your email and password.</span>
              )
            ) : (
              "Choose a strong password — only you will ever know it."
            )}
          </p>
        </div>

        {isLogin && (
          <nav className="nx-nav" aria-label="Login method">
            {TABS.map((t) => (
              <label key={t.id} className="nx-tab" htmlFor={t.radio} data-selected={provider === t.id ? "true" : undefined}>
                <span className="nx-chip">{ICONS[t.id]}</span>
                <span className="nx-label">{t.label}</span>
              </label>
            ))}
          </nav>
        )}

        {social ? (
          <div className="nx-card nx-anim">
            {oauthReady ? (
              <>
                <p className="nx-note">
                  You will be redirected to {provider} to sign in securely. We only receive your name and email.
                </p>
                <button type="button" className="nx-cta" disabled={busy} onClick={() => startOAuth(provider)}>
                  <span>{busy ? "Redirecting…" : `Continue with ${provider}`}</span>
                  <span className="nx-arrow" aria-hidden="true">
                    →
                  </span>
                </button>
              </>
            ) : (
              <>
                <div className="nx-note">
                  {provider} sign-in isn&apos;t enabled on this store yet. Use your email and password instead.
                </div>
                <button type="button" className="nx-ghost" onClick={() => setProvider("email")}>
                  Use email instead
                </button>
              </>
            )}
          </div>
        ) : (
          <form className="nx-card" onSubmit={onSubmit} noValidate={false} autoComplete="on">
            {error && (
              <div className="nx-error" role="alert" aria-live="assertive">
                {error}
              </div>
            )}

            {!isLogin && (
              <div className="nx-field">
                <label className="nx-l" htmlFor="name">
                  Full name
                </label>
                <div className="nx-input">
                  <input
                    id="name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    placeholder="Your name"
                    required
                    minLength={2}
                    maxLength={60}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
              </div>
            )}

            <div className="nx-field">
              <label className="nx-l" htmlFor="email">
                Email
              </label>
              <div className="nx-input">
                <input
                  id="email"
                  name="email"
                  type="email"
                  inputMode="email"
                  autoComplete={isLogin ? "username" : "email"}
                  placeholder="you@example.com"
                  required
                  maxLength={254}
                  autoCapitalize="none"
                  spellCheck={false}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="nx-field">
              <label className="nx-l" htmlFor="pw">
                Password
              </label>
              <div className="nx-input">
                <input
                  id="pw"
                  name="password"
                  type={showPw ? "text" : "password"}
                  autoComplete={isLogin ? "current-password" : "new-password"}
                  placeholder={isLogin ? "••••••••••" : "At least 12 characters"}
                  required
                  minLength={isLogin ? 1 : 12}
                  maxLength={128}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button type="button" className="nx-show" onClick={() => setShowPw((v) => !v)} aria-pressed={showPw}>
                  {showPw ? "Hide" : "Show"}
                </button>
              </div>
              {!isLogin && (
                <>
                  <div className="nx-meter" data-s={s} aria-hidden="true">
                    <span />
                    <span />
                    <span />
                    <span />
                  </div>
                  <div className="nx-hint">12+ characters, mixed types — or a 16+ character passphrase.</div>
                </>
              )}
            </div>

            {!isLogin && (
              <div className="nx-field">
                <label className="nx-l" htmlFor="confirm">
                  Confirm password
                </label>
                <div className="nx-input">
                  <input
                    id="confirm"
                    name="confirm"
                    type={showPw ? "text" : "password"}
                    autoComplete="new-password"
                    placeholder="Repeat password"
                    required
                    maxLength={128}
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                  />
                </div>
              </div>
            )}

            {/* Honeypot — invisible to humans, bots fill it in */}
            <div className="nx-hp" aria-hidden="true">
              <label htmlFor="website">Website</label>
              <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" ref={honeypot} defaultValue="" />
            </div>

            {isLogin && (
              <div className="nx-options">
                <label className="nx-remember">
                  <input type="checkbox" name="remember" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
                  <span className="nx-toggle" />
                  Remember me
                </label>
              </div>
            )}

            {!isLogin && (
              <label
                style={{
                  display: "flex",
                  gap: 10,
                  alignItems: "flex-start",
                  fontSize: 12.5,
                  lineHeight: 1.45,
                  color: "var(--olive-deep, #232D0F)",
                  marginBottom: 4,
                }}
              >
                <input type="checkbox" name="consent" required style={{ marginTop: 3, flexShrink: 0 }} />
                <span>
                  I agree to the{" "}
                  <Link href="/terms" className="nx-link" target="_blank" rel="noopener">
                    Terms &amp; Conditions
                  </Link>{" "}
                  and{" "}
                  <Link href="/privacy" className="nx-link" target="_blank" rel="noopener">
                    Privacy Policy
                  </Link>
                  . I consent to the collection of my name, email and account data solely for
                  account creation, order fulfilment and security, as described in the Privacy
                  Policy.
                </span>
              </label>
            )}

            {SITE_KEY && <div ref={tsBox} />}

            <button className="nx-cta" type="submit" disabled={busy || !ready}>
              <span>{busy ? "Please wait…" : isLogin ? "Sign in" : "Create account"}</span>
              <span className="nx-arrow" aria-hidden="true">
                →
              </span>
            </button>
          </form>
        )}

        <p className="nx-foot">
          {isLogin ? (
            <>
              New here?{" "}
              <Link className="nx-link" href="/register">
                Create account
              </Link>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <Link className="nx-link" href="/login">
                Sign in
              </Link>
            </>
          )}
        </p>
        <p className="nx-pill">
          <i />
          Secure sign-in · bot-shielded · OAuth-ready
        </p>
      </main>
    </div>
  );
}
