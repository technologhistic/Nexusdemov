"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import type { Product } from "@/data/products";
import ProductImage from "@/components/ProductImage";

function formatPrice(n: number) {
  return `NPR ${n.toLocaleString("en-NP")}`;
}

type SortKey = "relevance" | "price-asc" | "price-desc" | "rating" | "sold" | "newest";

export default function ProductsBrowser({
  products,
  categories,
  initialCategory = "",
}: {
  products: Product[];
  categories: string[];
  initialCategory?: string;
}) {
  const [q, setQ] = useState("");
  const [category, setCategory] = useState(initialCategory);
  const [sort, setSort] = useState<SortKey>("relevance");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [inStockOnly, setInStockOnly] = useState(false);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    const min = minPrice ? Number(minPrice) : 0;
    const max = maxPrice ? Number(maxPrice) : Infinity;

    let list = products.filter((p) => {
      if (category && p.category !== category) return false;
      if (inStockOnly && !p.inStock) return false;
      if (p.price < min || p.price > max) return false;
      if (!query) return true;
      const hay = `${p.name} ${p.brand} ${p.category} ${p.subcategory || ""} ${p.description}`.toLowerCase();
      return hay.includes(query);
    });

    list = [...list];
    switch (sort) {
      case "price-asc":
        list.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        list.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        list.sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount);
        break;
      case "sold":
        list.sort((a, b) => b.sold - a.sold);
        break;
      case "newest":
        list.sort((a, b) => Number(b.id) - Number(a.id));
        break;
      default:
        // relevance: keep original order, or boost name matches
        if (query) {
          list.sort((a, b) => {
            const aName = a.name.toLowerCase().includes(query) ? 1 : 0;
            const bName = b.name.toLowerCase().includes(query) ? 1 : 0;
            return bName - aName || b.sold - a.sold;
          });
        }
        break;
    }
    return list;
  }, [products, q, category, sort, minPrice, maxPrice, inStockOnly]);

  function clearFilters() {
    setQ("");
    setCategory("");
    setSort("relevance");
    setMinPrice("");
    setMaxPrice("");
    setInStockOnly(false);
  }

  const hasFilters = q || category || minPrice || maxPrice || inStockOnly || sort !== "relevance";

  return (
    <div>
      {/* Search */}
      <div style={{ marginBottom: 20 }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            maxWidth: 560,
            height: 48,
            padding: "0 16px",
            background: "rgba(245,238,220,0.7)",
            border: "1px solid rgba(59,74,31,0.18)",
            borderRadius: 14,
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--slate)" strokeWidth="2">
            <circle cx="11" cy="11" r="7" />
            <path d="M20 20l-3-3" />
          </svg>
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search products, brands, categories…"
            style={{
              flex: 1,
              border: 0,
              outline: 0,
              background: "transparent",
              font: "inherit",
              fontSize: 15,
              color: "var(--black)",
            }}
          />
          {q && (
            <button
              type="button"
              onClick={() => setQ("")}
              style={{ border: 0, background: "none", color: "var(--slate)", cursor: "pointer", fontSize: 13 }}
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Category chips */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 16 }}>
        <button
          type="button"
          onClick={() => setCategory("")}
          style={chipStyle(!category)}
        >
          All
        </button>
        {categories.map((c) => (
          <button key={c} type="button" onClick={() => setCategory(c)} style={chipStyle(category === c)}>
            {c}
          </button>
        ))}
      </div>

      {/* Filters row */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 12,
          alignItems: "center",
          marginBottom: 24,
          padding: "12px 0",
          borderTop: "1px solid rgba(59,74,31,0.1)",
          borderBottom: "1px solid rgba(59,74,31,0.1)",
        }}
      >
        <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
          <span style={{ color: "var(--slate)" }}>Sort</span>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            style={selectStyle}
          >
            <option value="relevance">Relevance</option>
            <option value="sold">Best selling</option>
            <option value="rating">Top rated</option>
            <option value="price-asc">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
            <option value="newest">Newest</option>
          </select>
        </label>

        <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
          <span style={{ color: "var(--slate)" }}>Min</span>
          <input
            type="number"
            min={0}
            value={minPrice}
            onChange={(e) => setMinPrice(e.target.value)}
            placeholder="0"
            style={{ ...selectStyle, width: 90 }}
          />
        </label>
        <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
          <span style={{ color: "var(--slate)" }}>Max</span>
          <input
            type="number"
            min={0}
            value={maxPrice}
            onChange={(e) => setMaxPrice(e.target.value)}
            placeholder="Any"
            style={{ ...selectStyle, width: 90 }}
          />
        </label>

        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, cursor: "pointer" }}>
          <input type="checkbox" checked={inStockOnly} onChange={(e) => setInStockOnly(e.target.checked)} />
          In stock only
        </label>

        {hasFilters && (
          <button
            type="button"
            onClick={clearFilters}
            style={{
              marginLeft: "auto",
              border: 0,
              background: "none",
              color: "var(--olive)",
              fontWeight: 600,
              fontSize: 13,
              cursor: "pointer",
            }}
          >
            Reset filters
          </button>
        )}
      </div>

      <p style={{ color: "var(--slate)", marginBottom: 20, fontSize: 14 }}>
        {filtered.length} product{filtered.length === 1 ? "" : "s"}
        {category ? ` in ${category}` : ""}
        {q ? ` matching “${q}”` : ""}
      </p>

      {filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "48px 20px", color: "var(--slate)" }}>
          <p style={{ fontSize: 18, marginBottom: 8 }}>No products found</p>
          <p style={{ marginBottom: 20 }}>Try a different search or clear filters.</p>
          <button type="button" className="btn-primary" onClick={clearFilters}>
            Clear filters
          </button>
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
            gap: 20,
          }}
        >
          {filtered.map((p) => {
            const discount =
              p.originalPrice && p.originalPrice > p.price
                ? Math.round(((p.originalPrice - p.price) / p.originalPrice) * 100)
                : 0;
            return (
              <Link
                key={p.id}
                href={`/products/${p.slug}`}
                className="card"
                style={{ overflow: "hidden", display: "block", position: "relative" }}
              >
                <div style={{ aspectRatio: "1", background: "#e8e0c8", position: "relative" }}>
                  <ProductImage src={p.image} alt={p.name} />
                  {p.badge && (
                    <span
                      style={{
                        position: "absolute",
                        top: 10,
                        left: 10,
                        background: "var(--lime)",
                        color: "var(--olive-deep)",
                        fontSize: 11,
                        fontWeight: 700,
                        padding: "3px 8px",
                        borderRadius: 8,
                      }}
                    >
                      {p.badge}
                    </span>
                  )}
                  {discount > 0 && (
                    <span
                      style={{
                        position: "absolute",
                        top: 10,
                        right: 10,
                        background: "#C62828",
                        color: "#fff",
                        fontSize: 11,
                        fontWeight: 700,
                        padding: "3px 8px",
                        borderRadius: 8,
                      }}
                    >
                      -{discount}%
                    </span>
                  )}
                </div>
                <div style={{ padding: 14 }}>
                  <div style={{ fontSize: 11, color: "var(--slate)", marginBottom: 2 }}>{p.brand}</div>
                  <h3
                    style={{
                      fontSize: 14,
                      fontWeight: 600,
                      color: "var(--olive-deep)",
                      margin: "0 0 6px",
                      lineHeight: 1.3,
                      display: "-webkit-box",
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: "vertical",
                      overflow: "hidden",
                    }}
                  >
                    {p.name}
                  </h3>
                  <div style={{ fontSize: 12, color: "#E8A33D", marginBottom: 6 }}>
                    ★ {p.rating.toFixed(1)} · {p.sold.toLocaleString()} sold
                  </div>
                  <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                    <span style={{ fontWeight: 800, color: "var(--olive)", fontSize: 16 }}>
                      {formatPrice(p.price)}
                    </span>
                    {p.originalPrice && (
                      <span style={{ fontSize: 12, color: "var(--slate)", textDecoration: "line-through" }}>
                        {formatPrice(p.originalPrice)}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

const chipStyle = (active: boolean): React.CSSProperties => ({
  padding: "8px 14px",
  borderRadius: 20,
  border: 0,
  background: active ? "var(--olive)" : "rgba(59,74,31,0.1)",
  color: active ? "#fff" : "var(--olive)",
  fontSize: 13,
  fontWeight: 600,
  cursor: "pointer",
});

const selectStyle: React.CSSProperties = {
  height: 36,
  padding: "0 10px",
  borderRadius: 10,
  border: "1px solid rgba(59,74,31,0.18)",
  background: "#fff",
  font: "inherit",
  fontSize: 13,
};
