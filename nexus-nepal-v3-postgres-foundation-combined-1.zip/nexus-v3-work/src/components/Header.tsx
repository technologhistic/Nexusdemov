"use client";

import Link from "next/link";
import { useState } from "react";
import { useCart } from "@/lib/cart";
import Logo from "./Logo";

export default function Header({ user }: { user: { name: string } | null }) {
  const { count: cartCount } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header
      style={{
        position: "sticky",
        top: 0,
        zIndex: 50,
        background: "linear-gradient(135deg, #4F6428, #2F3B16 60%, #232D0F)",
        boxShadow: "0 10px 24px rgba(35,45,15,0.28), inset 0 1px 0 rgba(255,255,255,0.12)",
      }}
    >
      <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 72, gap: 16 }}>
        <Logo size="md" />

        <nav style={{ display: "flex", alignItems: "center", gap: 28 }} className="desktop-nav">
          <Link href="/" style={{ color: "#F5EEDC", fontWeight: 600, fontSize: 15 }}>Home</Link>
          <Link href="/products" style={{ color: "#F5EEDC", fontWeight: 600, fontSize: 15 }}>Shop</Link>
          <Link href="/business" style={{ color: "#F5EEDC", fontWeight: 600, fontSize: 15 }}>Compliance</Link>
          <Link href="/grievance" style={{ color: "#F5EEDC", fontWeight: 600, fontSize: 15 }}>Support</Link>
        </nav>

        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Link
            href="/cart"
            style={{
              position: "relative",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 44,
              height: 44,
              borderRadius: 22,
              background: "rgba(255,255,255,0.12)",
              color: "#B8F235",
            }}
            aria-label="Cart"
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="9" cy="20" r="1.5" />
              <circle cx="17" cy="20" r="1.5" />
              <path d="M3 4h2l2.5 11h10l2-7H7" />
            </svg>
            {cartCount > 0 && (
              <span
                style={{
                  position: "absolute",
                  top: -4,
                  right: -4,
                  minWidth: 18,
                  height: 18,
                  borderRadius: 9,
                  background: "#B8F235",
                  color: "#232D0F",
                  fontSize: 11,
                  fontWeight: 700,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {cartCount}
              </span>
            )}
          </Link>

          <Link
            href={user ? "/account" : "/login"}
            className="btn-lime"
            style={{ height: 40, padding: "0 16px", fontSize: 13, maxWidth: 140, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}
          >
            {user ? user.name.split(" ")[0] : "Sign in"}
          </Link>
        </div>
      </div>
    </header>
  );
}
