import Image from "next/image";

export default function ProductImage({
  src,
  alt,
  priority = false,
}: {
  src: string;
  alt: string;
  priority?: boolean;
}) {
  return (
    <Image
      src={src}
      alt={alt}
      width={600}
      height={600}
      priority={priority}
      unoptimized
      style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
    />
  );
}
