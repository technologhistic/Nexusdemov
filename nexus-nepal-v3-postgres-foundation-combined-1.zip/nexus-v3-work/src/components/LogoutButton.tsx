"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function LogoutButton() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    try {
      await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" });
    } finally {
      router.push("/login");
      router.refresh();
    }
  }

  return (
    <button className="btn-primary" onClick={logout} disabled={busy} style={{ minWidth: 160 }}>
      {busy ? "Signing out…" : "Sign out"}
    </button>
  );
}
