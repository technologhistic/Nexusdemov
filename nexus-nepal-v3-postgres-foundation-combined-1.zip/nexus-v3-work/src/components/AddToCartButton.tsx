"use client";

import { useState } from "react";
import { useCart } from "@/lib/cart";

export default function AddToCartButton({
  productId,
  disabled,
}: {
  productId: string;
  disabled?: boolean;
}) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);

  function handleClick() {
    if (disabled) return;
    add(productId, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  return (
    <button
      type="button"
      className="btn-primary"
      style={{ minWidth: 180, height: 48, borderRadius: 24, opacity: disabled ? 0.5 : 1 }}
      disabled={disabled}
      onClick={handleClick}
    >
      {added ? "Added ✓" : "Add to Cart"}
    </button>
  );
}
