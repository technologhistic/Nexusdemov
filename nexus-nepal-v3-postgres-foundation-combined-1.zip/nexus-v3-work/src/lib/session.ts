import { cookies } from "next/headers";
import { addSession, deleteSession, findSession, findUserById, type User } from "./db";
import { newSessionToken, sha256 } from "./security";

const PROD = process.env.NODE_ENV === "production";
// __Host- prefix: Secure, Path=/, no Domain → cannot be overwritten by subdomains.
export const COOKIE_NAME = PROD ? "__Host-nx_session" : "nx_session";

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;

export async function startSession(userId: string, remember: boolean) {
  const token = newSessionToken();
  const ttl = remember ? 30 * DAY : 12 * HOUR;
  await addSession({
    tokenHash: sha256(token),
    userId,
    createdAt: Date.now(),
    expiresAt: Date.now() + ttl,
  });
  const jar = await cookies();
  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: PROD,
    sameSite: "lax",
    path: "/",
    ...(remember ? { maxAge: Math.floor(ttl / 1000) } : {}), // else: browser-session cookie
  });
}

export async function endSession() {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (token) await deleteSession(sha256(token));
  jar.delete(COOKIE_NAME);
}

export type PublicUser = Pick<User, "id" | "name" | "email">;

export async function getCurrentUser(): Promise<PublicUser | null> {
  const token = (await cookies()).get(COOKIE_NAME)?.value;
  if (!token || token.length > 100) return null;
  const session = await findSession(sha256(token));
  if (!session) return null;
  const user = await findUserById(session.userId);
  return user ? { id: user.id, name: user.name, email: user.email } : null;
}
