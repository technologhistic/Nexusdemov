import { NextResponse } from "next/server";
import { clientIp, rateLimit, sameOrigin, verifyChallenge } from "./security";

const HEADERS = { "Cache-Control": "no-store, max-age=0", "X-Content-Type-Options": "nosniff" };

export function json(body: Record<string, unknown>, status = 200, extra: Record<string, string> = {}) {
  return NextResponse.json(body, { status, headers: { ...HEADERS, ...extra } });
}

const BOT_UA = /(curl|wget|python-requests|python-urllib|aiohttp|httpclient|okhttp\/[0-9]|go-http-client|libwww|scrapy|java\/|postman|insomnia|headless|phantomjs|selenium|puppeteer|playwright|bot\b|spider|crawler)/i;

export type Guarded = { body: Record<string, unknown>; ip: string };

/**
 * Common protections for every state-changing auth endpoint:
 * same-origin, JSON only, small body, bot user-agents, IP rate limit,
 * honeypot, signed single-use time-gated challenge, optional Cloudflare Turnstile.
 */
export async function guardPost(
  req: Request,
  opts: { name: string; limit: number; windowMs: number }
): Promise<Guarded | Response> {
  const ip = clientIp(req.headers);

  const rl = rateLimit(`${opts.name}:ip:${ip}`, opts.limit, opts.windowMs);
  if (!rl.ok) {
    return json({ error: "Too many attempts. Please wait and try again." }, 429, {
      "Retry-After": String(rl.retryAfterSec),
    });
  }

  if (!sameOrigin(req.headers)) return json({ error: "Request blocked." }, 403);

  const ua = req.headers.get("user-agent") || "";
  if (ua.length < 10 || BOT_UA.test(ua)) return json({ error: "Request blocked." }, 403);

  if (!(req.headers.get("content-type") || "").toLowerCase().startsWith("application/json")) {
    return json({ error: "Unsupported request." }, 415);
  }

  const raw = await req.text();
  if (raw.length > 4096) return json({ error: "Request too large." }, 413);

  let body: Record<string, unknown>;
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error();
    body = parsed as Record<string, unknown>;
  } catch {
    return json({ error: "Invalid request." }, 400);
  }

  // Honeypot: real users never see or fill this field.
  if (typeof body.website === "string" && body.website.length > 0) {
    return json({ error: "Something went wrong. Please refresh and try again." }, 400);
  }

  const ch = verifyChallenge(body.challenge);
  if (ch !== "ok") {
    return json(
      { error: ch === "too-fast" ? "Please slow down and try again." : "Session expired. Please try again.", refresh: true },
      400
    );
  }

  if (process.env.TURNSTILE_SECRET_KEY) {
    const token = typeof body.turnstile === "string" ? body.turnstile.slice(0, 2048) : "";
    if (!token || !(await verifyTurnstile(token, ip))) {
      return json({ error: "Human verification failed. Please try again.", refresh: true }, 400);
    }
  }

  return { body, ip };
}

async function verifyTurnstile(token: string, ip: string): Promise<boolean> {
  try {
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ secret: process.env.TURNSTILE_SECRET_KEY!, response: token, remoteip: ip }),
      signal: AbortSignal.timeout(5000),
    });
    const data = (await res.json()) as { success?: boolean };
    return data.success === true;
  } catch {
    return false; // fail closed
  }
}
