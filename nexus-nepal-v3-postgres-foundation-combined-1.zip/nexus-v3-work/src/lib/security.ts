import {
  createHash,
  createHmac,
  randomBytes,
  scrypt as scryptCb,
  timingSafeEqual,
} from "node:crypto";

/* ------------------------------------------------------------------ */
/* Secret                                                              */
/* ------------------------------------------------------------------ */

let cachedSecret: Buffer | null = null;

/** Server secret. REQUIRED in production (AUTH_SECRET, 32+ random chars). */
export function getSecret(): Buffer {
  if (cachedSecret) return cachedSecret;
  const env = process.env.AUTH_SECRET;
  if (env && env.length >= 32) {
    cachedSecret = Buffer.from(env, "utf8");
    return cachedSecret;
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error("AUTH_SECRET must be set (32+ characters) in production.");
  }
  // Dev only: stable per-process secret (sessions are server-side, so this is fine)
  cachedSecret = randomBytes(48);
  return cachedSecret;
}

/* ------------------------------------------------------------------ */
/* Password hashing (scrypt + HMAC pepper)                             */
/* ------------------------------------------------------------------ */

const SCRYPT_N = 2 ** 15; // 32768
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const KEYLEN = 64;
const MAXMEM = 128 * 1024 * 1024;

function scrypt(password: Buffer, salt: Buffer, n: number, r: number, p: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCb(password, salt, KEYLEN, { N: n, r, p, maxmem: MAXMEM }, (err, key) =>
      err ? reject(err) : resolve(key)
    );
  });
}

function pepper(password: string): Buffer {
  // Pepper: a DB leak alone is not enough to attack hashes offline.
  return createHmac("sha512", getSecret()).update(password.normalize("NFKC")).digest();
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scrypt(pepper(password), salt, SCRYPT_N, SCRYPT_R, SCRYPT_P);
  return ["scrypt", SCRYPT_N, SCRYPT_R, SCRYPT_P, salt.toString("base64"), key.toString("base64")].join("$");
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const n = Number(parts[1]);
  const r = Number(parts[2]);
  const p = Number(parts[3]);
  if (!Number.isInteger(n) || !Number.isInteger(r) || !Number.isInteger(p)) return false;
  if (n > 2 ** 16 || r > 16 || p > 4) return false; // refuse absurd params
  const salt = Buffer.from(parts[4], "base64");
  const expected = Buffer.from(parts[5], "base64");
  const actual = await scrypt(pepper(password), salt, n, r, p);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

let dummyHashPromise: Promise<string> | null = null;
/** Verify against a dummy hash so "unknown email" costs the same as "wrong password". */
export async function burnPasswordCheck(password: string): Promise<void> {
  dummyHashPromise ??= hashPassword("dummy-password-for-timing-equalisation");
  await verifyPassword(password, await dummyHashPromise);
}

/* ------------------------------------------------------------------ */
/* Tokens                                                              */
/* ------------------------------------------------------------------ */

export function newSessionToken(): string {
  return randomBytes(32).toString("base64url");
}

export function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export function newId(): string {
  return randomBytes(16).toString("hex");
}

export function hmac(data: string): string {
  return createHmac("sha256", getSecret()).update(data).digest("base64url");
}

function safeEqualStr(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

/* ------------------------------------------------------------------ */
/* Form challenge: signed, time-gated, single-use (CSRF + bot filter)  */
/* ------------------------------------------------------------------ */

const MIN_FORM_AGE_MS = 2_000; // humans take >2s; scripts submit instantly
const MAX_FORM_AGE_MS = 60 * 60 * 1000;
const usedNonces = new Map<string, number>();

export function issueChallenge(now = Date.now()): string {
  const nonce = randomBytes(12).toString("base64url");
  const body = `${now}.${nonce}`;
  return `${body}.${hmac(body)}`;
}

export type ChallengeResult = "ok" | "invalid" | "too-fast" | "expired" | "reused";

export function verifyChallenge(token: unknown, now = Date.now()): ChallengeResult {
  if (typeof token !== "string" || token.length > 200) return "invalid";
  const parts = token.split(".");
  if (parts.length !== 3) return "invalid";
  const [ts, nonce, sig] = parts;
  if (!safeEqualStr(sig, hmac(`${ts}.${nonce}`))) return "invalid";
  const issued = Number(ts);
  if (!Number.isFinite(issued)) return "invalid";
  const age = now - issued;
  if (age < MIN_FORM_AGE_MS) return "too-fast";
  if (age > MAX_FORM_AGE_MS) return "expired";
  // purge old nonces
  if (usedNonces.size > 5000) {
    for (const [k, exp] of usedNonces) if (exp < now) usedNonces.delete(k);
  }
  if (usedNonces.has(nonce)) return "reused";
  usedNonces.set(nonce, issued + MAX_FORM_AGE_MS);
  return "ok";
}

/* ------------------------------------------------------------------ */
/* Rate limiting (sliding window, in-memory)                           */
/* ------------------------------------------------------------------ */

const buckets = new Map<string, number[]>();

export function rateLimit(key: string, limit: number, windowMs: number, now = Date.now()) {
  const hits = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (hits.length >= limit) {
    buckets.set(key, hits);
    return { ok: false, retryAfterSec: Math.ceil((windowMs - (now - hits[0])) / 1000) };
  }
  hits.push(now);
  buckets.set(key, hits);
  if (buckets.size > 20_000) {
    for (const [k, v] of buckets) if (!v.some((t) => now - t < windowMs)) buckets.delete(k);
  }
  return { ok: true, retryAfterSec: 0 };
}

/* ------------------------------------------------------------------ */
/* Input validation                                                    */
/* ------------------------------------------------------------------ */

const EMAIL_RE = /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/;

export function normalizeEmail(input: unknown): string | null {
  if (typeof input !== "string") return null;
  const email = input.trim().toLowerCase();
  if (email.length < 6 || email.length > 254 || !EMAIL_RE.test(email)) return null;
  return email;
}

export function cleanName(input: unknown): string | null {
  if (typeof input !== "string") return null;
  // eslint-disable-next-line no-control-regex
  const name = input.normalize("NFKC").replace(/[\u0000-\u001f\u007f<>]/g, "").replace(/\s+/g, " ").trim();
  if (name.length < 2 || name.length > 60) return null;
  return name;
}

const COMMON_PASSWORDS = new Set([
  "password", "password1", "password123", "123456789", "12345678", "1234567890", "qwertyuiop", "qwerty123",
  "iloveyou", "admin123", "welcome1", "letmein123", "abc12345", "111111111", "000000000", "passw0rd",
  "nepal12345", "nexusnepal", "kathmandu", "namaste123", "football1", "monkey123", "dragon123", "sunshine1",
]);

export function checkPassword(password: unknown, email?: string | null, name?: string | null): string | null {
  if (typeof password !== "string") return "Enter a password.";
  if (password.length < 12) return "Use at least 12 characters.";
  if (password.length > 128) return "Use at most 128 characters.";
  const lower = password.toLowerCase();
  if (COMMON_PASSWORDS.has(lower)) return "That password is too common.";
  for (const bad of ["password", "qwerty", "123456", "nexusnepal", "letmein"]) {
    if (lower.includes(bad)) return "Avoid common words and sequences.";
  }
  if (/^(.)\1+$/.test(password)) return "Avoid repeating a single character.";
  const local = email?.split("@")[0];
  if (local && local.length >= 4 && lower.includes(local)) return "Don't include your email in the password.";
  const first = name?.split(" ")[0]?.toLowerCase();
  if (first && first.length >= 4 && lower.includes(first)) return "Don't include your name in the password.";
  const classes = [/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/].filter((re) => re.test(password)).length;
  if (password.length < 16 && classes < 3) {
    return "Mix upper/lower case, numbers and symbols — or use a 16+ character passphrase.";
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Request helpers                                                     */
/* ------------------------------------------------------------------ */

export function clientIp(headers: Headers): string {
  // Behind Vercel/Cloudflare the first x-forwarded-for hop is set by the platform.
  const xff = headers.get("x-forwarded-for");
  const ip = (xff?.split(",")[0] || headers.get("x-real-ip") || "unknown").trim();
  return ip.slice(0, 64);
}

export function sameOrigin(headers: Headers): boolean {
  const origin = headers.get("origin");
  const host = headers.get("x-forwarded-host") || headers.get("host");
  if (!origin || !host) return false;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
export const jitter = (min: number, max: number) => min + Math.floor(Math.random() * (max - min));
