import { createHash, randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { hmac, sha256 } from "./security";

export type OAuthProvider = "google" | "facebook";

const PROVIDERS: Record<
  OAuthProvider,
  {
    authUrl: string;
    tokenUrl: string;
    userUrl: string;
    scopes: string;
    clientIdEnv: string;
    clientSecretEnv: string;
  }
> = {
  google: {
    authUrl: "https://accounts.google.com/o/oauth2/v2/auth",
    tokenUrl: "https://oauth2.googleapis.com/token",
    userUrl: "https://www.googleapis.com/oauth2/v3/userinfo",
    scopes: "openid email profile",
    clientIdEnv: "GOOGLE_CLIENT_ID",
    clientSecretEnv: "GOOGLE_CLIENT_SECRET",
  },
  facebook: {
    authUrl: "https://www.facebook.com/v19.0/dialog/oauth",
    tokenUrl: "https://graph.facebook.com/v19.0/oauth/access_token",
    userUrl: "https://graph.facebook.com/me?fields=id,name,email",
    scopes: "email,public_profile",
    clientIdEnv: "FACEBOOK_CLIENT_ID",
    clientSecretEnv: "FACEBOOK_CLIENT_SECRET",
  },
};

export function isProviderConfigured(provider: OAuthProvider): boolean {
  const p = PROVIDERS[provider];
  return !!(process.env[p.clientIdEnv] && process.env[p.clientSecretEnv]);
}

export function getConfiguredProviders(): OAuthProvider[] {
  return (Object.keys(PROVIDERS) as OAuthProvider[]).filter(isProviderConfigured);
}

function base64url(buf: Buffer): string {
  return buf.toString("base64url");
}

/** Generate PKCE code_verifier + code_challenge (S256) */
export function createPkce() {
  const verifier = base64url(randomBytes(32));
  const challenge = base64url(createHash("sha256").update(verifier).digest());
  return { verifier, challenge };
}

/** Signed state that also carries the provider + PKCE verifier hash */
export function createOAuthState(provider: OAuthProvider, verifier: string): string {
  const nonce = base64url(randomBytes(16));
  const issued = Date.now();
  const body = `${provider}.${issued}.${nonce}.${sha256(verifier).slice(0, 16)}`;
  return `${body}.${hmac(body)}`;
}

export function parseOAuthState(state: string): { provider: OAuthProvider; issued: number; ok: boolean } {
  if (typeof state !== "string" || state.length > 300) return { provider: "google", issued: 0, ok: false };
  const parts = state.split(".");
  if (parts.length !== 5) return { provider: "google", issued: 0, ok: false };
  const [provider, ts, , , sig] = parts;
  const body = parts.slice(0, 4).join(".");
  if (!["google", "facebook"].includes(provider)) return { provider: "google", issued: 0, ok: false };
  if (sig !== hmac(body)) return { provider: "google", issued: 0, ok: false };
  const issued = Number(ts);
  if (!Number.isFinite(issued) || Date.now() - issued > 15 * 60 * 1000) {
    return { provider: provider as OAuthProvider, issued, ok: false };
  }
  return { provider: provider as OAuthProvider, issued, ok: true };
}

const PKCE_COOKIE = "nx_pkce";

export async function storePkceVerifier(verifier: string) {
  const jar = await cookies();
  jar.set(PKCE_COOKIE, verifier, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 15 * 60, // 15 min
  });
}

export async function takePkceVerifier(): Promise<string | null> {
  const jar = await cookies();
  const v = jar.get(PKCE_COOKIE)?.value ?? null;
  jar.delete(PKCE_COOKIE);
  return v && v.length >= 32 && v.length <= 128 ? v : null;
}

export function buildAuthorizeUrl(
  provider: OAuthProvider,
  redirectUri: string,
  state: string,
  codeChallenge: string
): string {
  const p = PROVIDERS[provider];
  const clientId = process.env[p.clientIdEnv]!;
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: p.scopes,
    state,
    code_challenge: codeChallenge,
    code_challenge_method: "S256",
  });
  if (provider === "google") {
    params.set("access_type", "online");
    params.set("prompt", "select_account");
  }
  return `${p.authUrl}?${params.toString()}`;
}

export async function exchangeCode(
  provider: OAuthProvider,
  code: string,
  redirectUri: string,
  codeVerifier: string
): Promise<{ access_token: string } | null> {
  const p = PROVIDERS[provider];
  const body = new URLSearchParams({
    client_id: process.env[p.clientIdEnv]!,
    client_secret: process.env[p.clientSecretEnv]!,
    code,
    redirect_uri: redirectUri,
    grant_type: "authorization_code",
    code_verifier: codeVerifier,
  });

  try {
    const res = await fetch(p.tokenUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
      body,
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { access_token?: string };
    return data.access_token ? { access_token: data.access_token } : null;
  } catch {
    return null;
  }
}

export async function fetchUserProfile(
  provider: OAuthProvider,
  accessToken: string
): Promise<{ id: string; email: string; name: string } | null> {
  const p = PROVIDERS[provider];
  try {
    const res = await fetch(p.userUrl, {
      headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as Record<string, unknown>;

    if (provider === "google") {
      const email = typeof data.email === "string" ? data.email.toLowerCase() : null;
      const name = typeof data.name === "string" ? data.name : email?.split("@")[0] || "User";
      const id = typeof data.sub === "string" ? data.sub : null;
      if (!email || !id) return null;
      return { id, email, name };
    }

    // Facebook
    const email = typeof data.email === "string" ? data.email.toLowerCase() : null;
    const name = typeof data.name === "string" ? data.name : email?.split("@")[0] || "User";
    const id = typeof data.id === "string" ? data.id : null;
    if (!email || !id) return null; // we require email
    return { id, email, name };
  } catch {
    return null;
  }
}

export function getRedirectUri(provider: OAuthProvider, req: Request): string {
  const host = req.headers.get("x-forwarded-host") || req.headers.get("host") || "localhost:3000";
  const proto = req.headers.get("x-forwarded-proto") || (process.env.NODE_ENV === "production" ? "https" : "http");
  return `${proto}://${host}/api/auth/callback/${provider}`;
}
