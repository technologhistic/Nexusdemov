import { promises as fs } from "node:fs";
import path from "node:path";
import { Pool, type PoolClient } from "pg";

/**
 * Persistence boundary for auth/session data.
 * - Local development may use the JSON demo store when DATABASE_URL is absent.
 * - Production MUST use PostgreSQL and fails closed if DATABASE_URL is missing.
 * Never use the JSON adapter for production traffic.
 */
export type User = {
  id: string;
  name: string;
  email: string;
  passwordHash: string; // empty string = OAuth-only account (legacy app contract)
  createdAt: number;
  lastLoginAt: number | null;
  failedCount: number;
  lockedUntil: number;
  oauthProvider?: string;
  oauthId?: string;
};

export type Session = {
  tokenHash: string;
  userId: string;
  createdAt: number;
  expiresAt: number;
};

type Data = { users: User[]; sessions: Session[] };
function usePostgres(): boolean {
  if (process.env.DATABASE_URL) return true;
  if (process.env.NODE_ENV === "production") {
    throw new Error("DATABASE_URL is required in production; refusing to use the JSON demo store.");
  }
  return false;
}

let pool: Pool | null = null;
function getPool(): Pool {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required for PostgreSQL persistence.");
  if (!pool) {
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : undefined,
      max: Number(process.env.DATABASE_POOL_MAX || 10),
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 5_000,
      application_name: "nexus-nepal-web",
    });
    pool.on("error", (error) => console.error("Unexpected idle PostgreSQL client error", error));
  }
  return pool;
}

type DbUser = {
  id: string; name: string; email: string; password_hash: string | null;
  created_at: Date; last_login_at: Date | null; failed_count: number; locked_until: Date | null;
  oauth_provider: string | null; oauth_subject: string | null;
};
function fromDbUser(row: DbUser): User {
  return {
    id: row.id, name: row.name, email: row.email, passwordHash: row.password_hash ?? "",
    createdAt: row.created_at.getTime(), lastLoginAt: row.last_login_at?.getTime() ?? null,
    failedCount: row.failed_count, lockedUntil: row.locked_until?.getTime() ?? 0,
    ...(row.oauth_provider ? { oauthProvider: row.oauth_provider } : {}),
    ...(row.oauth_subject ? { oauthId: row.oauth_subject } : {}),
  };
}
const USER_COLUMNS = `id, name, email, password_hash, created_at, last_login_at, failed_count, locked_until, oauth_provider, oauth_subject`;

// ----------------------------- JSON demo adapter -----------------------------
const DIR = process.env.AUTH_DATA_DIR || path.join(process.cwd(), ".data");
const FILE = path.join(DIR, "auth.json");
let cache: Data | null = null;
let chain: Promise<unknown> = Promise.resolve();

async function load(): Promise<Data> {
  if (cache) return cache;
  try {
    cache = JSON.parse(await fs.readFile(FILE, "utf8")) as Data;
  } catch (error) {
    // Missing file is expected for a fresh local demo; corrupt/unreadable files are not.
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
      throw new Error(`Unable to read JSON demo store (${FILE}); refusing to reset it silently.`, { cause: error });
    }
    cache = { users: [], sessions: [] };
  }
  return cache;
}
async function persist(data: Data) {
  await fs.mkdir(DIR, { recursive: true, mode: 0o700 });
  const tmp = `${FILE}.${process.pid}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data), { mode: 0o600 });
  await fs.rename(tmp, FILE);
}
function mutate<T>(fn: (d: Data) => T): Promise<T> {
  const run = chain.then(async () => {
    const data = await load();
    const result = fn(data);
    await persist(data);
    return result;
  });
  chain = run.catch(() => undefined);
  return run;
}

export async function findUserByEmail(email: string): Promise<User | undefined> {
  if (usePostgres()) {
    const result = await getPool().query<DbUser>(`SELECT ${USER_COLUMNS} FROM users WHERE email = lower($1) LIMIT 1`, [email]);
    return result.rows[0] ? fromDbUser(result.rows[0]) : undefined;
  }
  return (await load()).users.find((u) => u.email.toLowerCase() === email.toLowerCase());
}

export async function findUserById(id: string): Promise<User | undefined> {
  if (usePostgres()) {
    const result = await getPool().query<DbUser>(`SELECT ${USER_COLUMNS} FROM users WHERE id = $1 LIMIT 1`, [id]);
    return result.rows[0] ? fromDbUser(result.rows[0]) : undefined;
  }
  return (await load()).users.find((u) => u.id === id);
}

/** Returns false if the normalized email or OAuth identity already exists. */
export async function createUser(user: User): Promise<boolean> {
  if (usePostgres()) {
    try {
      await getPool().query(
        `INSERT INTO users (id, name, email, password_hash, created_at, last_login_at, failed_count, locked_until, oauth_provider, oauth_subject)
         VALUES ($1, $2, lower($3), $4, to_timestamp($5 / 1000.0), CASE WHEN $6::bigint IS NULL THEN NULL ELSE to_timestamp($6 / 1000.0) END, $7,
           CASE WHEN $8::bigint <= 0 THEN NULL ELSE to_timestamp($8 / 1000.0) END, $9, $10)`,
        [user.id, user.name, user.email, user.passwordHash || null, user.createdAt, user.lastLoginAt, user.failedCount, user.lockedUntil, user.oauthProvider ?? null, user.oauthId ?? null]
      );
      return true;
    } catch (error) {
      if ((error as { code?: string }).code === "23505") return false;
      throw error;
    }
  }
  return mutate((d) => {
    if (d.users.some((u) => u.email.toLowerCase() === user.email.toLowerCase() || (user.oauthProvider && user.oauthId && u.oauthProvider === user.oauthProvider && u.oauthId === user.oauthId))) return false;
    d.users.push(user);
    return true;
  });
}

export async function updateUser(id: string, patch: Partial<User>): Promise<void> {
  if (usePostgres()) {
    const fields: string[] = [];
    const values: unknown[] = [id];
    const add = (column: string, value: unknown, expression = "$VALUE") => {
      values.push(value);
      fields.push(`${column} = ${expression.replaceAll("$VALUE", `$${values.length}`)}`);
    };
    if (patch.name !== undefined) add("name", patch.name);
    if (patch.email !== undefined) add("email", patch.email.toLowerCase());
    if (patch.passwordHash !== undefined) add("password_hash", patch.passwordHash || null);
    if (patch.createdAt !== undefined) add("created_at", patch.createdAt, "to_timestamp($VALUE / 1000.0)");
    if (patch.lastLoginAt !== undefined) add("last_login_at", patch.lastLoginAt, "CASE WHEN $VALUE::bigint IS NULL THEN NULL ELSE to_timestamp($VALUE / 1000.0) END");
    if (patch.failedCount !== undefined) add("failed_count", patch.failedCount);
    if (patch.lockedUntil !== undefined) add("locked_until", patch.lockedUntil, "CASE WHEN $VALUE::bigint <= 0 THEN NULL ELSE to_timestamp($VALUE / 1000.0) END");
    if (patch.oauthProvider !== undefined) add("oauth_provider", patch.oauthProvider || null);
    if (patch.oauthId !== undefined) add("oauth_subject", patch.oauthId || null);
    if (fields.length) await getPool().query(`UPDATE users SET ${fields.join(", ")} WHERE id = $1`, values);
    return;
  }
  await mutate((d) => {
    const user = d.users.find((item) => item.id === id);
    if (user) Object.assign(user, patch);
  });
}

export async function addSession(session: Session): Promise<void> {
  if (usePostgres()) {
    const client: PoolClient = await getPool().connect();
    try {
      await client.query("BEGIN");
      // Lock the owner row so simultaneous logins cannot bypass the 5-session cap.
      const owner = await client.query("SELECT id FROM users WHERE id = $1 FOR UPDATE", [session.userId]);
      if (!owner.rowCount) throw new Error("Cannot create a session for a missing user.");
      await client.query("DELETE FROM sessions WHERE expires_at <= now() OR revoked_at IS NOT NULL");
      const existing = await client.query<{ token_hash: string }>(
        "SELECT token_hash FROM sessions WHERE user_id = $1 ORDER BY created_at ASC", [session.userId]
      );
      const excess = Math.max(0, existing.rowCount! - 4);
      if (excess) {
        await client.query("DELETE FROM sessions WHERE token_hash = ANY($1::char(64)[])", [existing.rows.slice(0, excess).map((row) => row.token_hash.trim())]);
      }
      await client.query(
        "INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES ($1, $2, to_timestamp($3 / 1000.0), to_timestamp($4 / 1000.0))",
        [session.tokenHash, session.userId, session.createdAt, session.expiresAt]
      );
      await client.query("COMMIT");
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally { client.release(); }
    return;
  }
  await mutate((d) => {
    const now = Date.now();
    d.sessions = d.sessions.filter((item) => item.expiresAt > now);
    const mine = d.sessions.filter((item) => item.userId === session.userId);
    if (mine.length >= 5) {
      const drop = new Set(mine.sort((a, b) => a.createdAt - b.createdAt).slice(0, mine.length - 4).map((item) => item.tokenHash));
      d.sessions = d.sessions.filter((item) => !drop.has(item.tokenHash));
    }
    d.sessions.push(session);
  });
}

export async function findSession(tokenHash: string): Promise<Session | undefined> {
  if (usePostgres()) {
    const result = await getPool().query<{ token_hash: string; user_id: string; created_at: Date; expires_at: Date }>(
      "SELECT token_hash, user_id, created_at, expires_at FROM sessions WHERE token_hash = $1 AND expires_at > now() AND revoked_at IS NULL LIMIT 1", [tokenHash]
    );
    const row = result.rows[0];
    return row ? { tokenHash: row.token_hash.trim(), userId: row.user_id, createdAt: row.created_at.getTime(), expiresAt: row.expires_at.getTime() } : undefined;
  }
  const now = Date.now();
  return (await load()).sessions.find((item) => item.tokenHash === tokenHash && item.expiresAt > now);
}

export async function deleteSession(tokenHash: string): Promise<void> {
  if (usePostgres()) {
    await getPool().query("UPDATE sessions SET revoked_at = now() WHERE token_hash = $1 AND revoked_at IS NULL", [tokenHash]);
    return;
  }
  await mutate((d) => { d.sessions = d.sessions.filter((item) => item.tokenHash !== tokenHash); });
}
