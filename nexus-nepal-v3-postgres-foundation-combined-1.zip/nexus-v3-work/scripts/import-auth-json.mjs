import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const { Pool } = pg;
const here = path.dirname(fileURLToPath(import.meta.url));
const sourcePath = path.resolve(process.env.AUTH_DATA_DIR || path.join(here, "..", ".data"), "auth.json");
const apply = process.argv.includes("--apply");
if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is required. No data was imported.");
  process.exit(1);
}
let source;
try {
  source = JSON.parse(await readFile(sourcePath, "utf8"));
} catch (error) {
  console.error(`Could not read a valid source JSON file at ${sourcePath}. No data was imported.`);
  process.exit(1);
}
if (!source || !Array.isArray(source.users) || !Array.isArray(source.sessions)) {
  console.error("Source must contain users[] and sessions[] arrays. No data was imported.");
  process.exit(1);
}

const emailSeen = new Set();
const idSeen = new Set();
const oauthSeen = new Set();
const problems = [];
const users = source.users.map((u, i) => {
  if (!u || typeof u.id !== "string" || !(/^[0-9a-f]{32}$/i.test(u.id) || /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(u.id)) || typeof u.name !== "string" || typeof u.email !== "string" || typeof u.createdAt !== "number") {
    problems.push(`users[${i}] has missing/invalid required fields`);
    return null;
  }
  const email = u.email.trim().toLowerCase();
  if (!email || email.length > 254 || !email.includes("@")) problems.push(`users[${i}] has an invalid email`);
  if (emailSeen.has(email)) problems.push(`duplicate normalized email: ${email}`);
  emailSeen.add(email);
  if (idSeen.has(u.id)) problems.push(`duplicate user id: ${u.id}`);
  idSeen.add(u.id);
  const oauthProvider = u.oauthProvider || null;
  const oauthSubject = u.oauthId || null;
  if ((oauthProvider && !oauthSubject) || (!oauthProvider && oauthSubject)) problems.push(`users[${i}] has an incomplete OAuth identity`);
  if (oauthProvider && oauthSubject) {
    const key = `${oauthProvider}:${oauthSubject}`;
    if (oauthSeen.has(key)) problems.push(`duplicate OAuth identity: ${oauthProvider}`);
    oauthSeen.add(key);
  }
  return {
    id: u.id, name: u.name, email, passwordHash: u.passwordHash || null,
    createdAt: u.createdAt, lastLoginAt: typeof u.lastLoginAt === "number" ? u.lastLoginAt : null,
    failedCount: Number.isInteger(u.failedCount) && u.failedCount >= 0 ? u.failedCount : 0,
    lockedUntil: typeof u.lockedUntil === "number" && u.lockedUntil > 0 ? u.lockedUntil : null,
    oauthProvider, oauthSubject,
  };
});
const knownUserIds = new Set(users.filter(Boolean).map((u) => u.id));
const tokenSeen = new Set();
const sessions = source.sessions.map((s, i) => {
  if (!s || typeof s.tokenHash !== "string" || !/^[a-f0-9]{64}$/i.test(s.tokenHash) || typeof s.userId !== "string" || typeof s.createdAt !== "number" || typeof s.expiresAt !== "number") {
    problems.push(`sessions[${i}] has invalid required fields or token hash`);
    return null;
  }
  if (!knownUserIds.has(s.userId)) problems.push(`sessions[${i}] references a missing user`);
  const token = s.tokenHash.toLowerCase();
  if (tokenSeen.has(token)) problems.push("duplicate session token hash");
  tokenSeen.add(token);
  return { tokenHash: token, userId: s.userId, createdAt: s.createdAt, expiresAt: s.expiresAt };
}).filter(Boolean);

if (problems.length) {
  console.error(`Preflight failed with ${problems.length} issue(s). No data was imported:`);
  for (const problem of problems) console.error(`- ${problem}`);
  process.exit(1);
}
console.log(`Source: ${sourcePath}`);
console.log(`Validated ${users.length} users and ${sessions.length} sessions. Password hashes and session token hashes are retained; OAuth-only empty password values become NULL.`);
if (!apply) {
  console.log("DRY RUN ONLY: database was not changed. Back up the JSON file, apply schema migrations, then rerun with --apply.");
  process.exit(0);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : undefined,
  max: 1,
  connectionTimeoutMillis: 5000,
  application_name: "nexus-nepal-auth-import",
});
const client = await pool.connect();
try {
  await client.query("BEGIN");
  const existing = await client.query("SELECT (SELECT count(*) FROM users)::int AS users, (SELECT count(*) FROM sessions)::int AS sessions");
  if (existing.rows[0].users || existing.rows[0].sessions) {
    throw new Error("Target users/sessions tables are not empty. Import stopped to avoid overwriting or silently merging data.");
  }
  for (const user of users) {
    await client.query(
      `INSERT INTO users (id, name, email, password_hash, created_at, last_login_at, failed_count, locked_until, oauth_provider, oauth_subject)
       VALUES ($1, $2, $3, $4, to_timestamp($5 / 1000.0), CASE WHEN $6::bigint IS NULL THEN NULL ELSE to_timestamp($6 / 1000.0) END, $7,
         CASE WHEN $8::bigint IS NULL THEN NULL ELSE to_timestamp($8 / 1000.0) END, $9, $10)`,
      [user.id, user.name, user.email, user.passwordHash, user.createdAt, user.lastLoginAt, user.failedCount, user.lockedUntil, user.oauthProvider, user.oauthSubject]
    );
  }
  for (const session of sessions) {
    if (session.expiresAt <= Date.now()) continue; // expired sessions are not usable and are intentionally not imported
    await client.query(
      "INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES ($1, $2, to_timestamp($3 / 1000.0), to_timestamp($4 / 1000.0))",
      [session.tokenHash, session.userId, session.createdAt, session.expiresAt]
    );
  }
  await client.query("COMMIT");
  console.log(`Import committed: ${users.length} users; ${sessions.filter((s) => s.expiresAt > Date.now()).length} unexpired sessions. Expired sessions were skipped.`);
} catch (error) {
  await client.query("ROLLBACK");
  console.error("Import failed and was rolled back. Source JSON remains unchanged.", error);
  process.exitCode = 1;
} finally {
  client.release();
  await pool.end();
}
