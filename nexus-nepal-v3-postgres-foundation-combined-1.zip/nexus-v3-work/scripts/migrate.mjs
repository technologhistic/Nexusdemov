import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const { Pool } = pg;
if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is required. No migration was run.");
  process.exit(1);
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: true } : undefined,
  max: 1,
  connectionTimeoutMillis: 5000,
  application_name: "nexus-nepal-migrations",
});
const here = path.dirname(fileURLToPath(import.meta.url));
const dir = path.join(here, "..", "db", "migrations");
const client = await pool.connect();
try {
  await client.query("BEGIN");
  await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version text PRIMARY KEY,
    applied_at timestamptz NOT NULL DEFAULT now()
  )`);
  await client.query("COMMIT");
  const files = (await readdir(dir)).filter((name) => /^\d+_[a-z0-9_-]+\.sql$/.test(name)).sort();
  for (const file of files) {
    const applied = await client.query("SELECT 1 FROM schema_migrations WHERE version = $1", [file]);
    if (applied.rowCount) {
      console.log(`skip ${file} (already applied)`);
      continue;
    }
    const sql = await readFile(path.join(dir, file), "utf8");
    await client.query("BEGIN");
    try {
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations (version) VALUES ($1)", [file]);
      await client.query("COMMIT");
      console.log(`applied ${file}`);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  }
} catch (error) {
  console.error("Migration failed; the current migration transaction was rolled back.", error);
  process.exitCode = 1;
} finally {
  client.release();
  await pool.end();
}
